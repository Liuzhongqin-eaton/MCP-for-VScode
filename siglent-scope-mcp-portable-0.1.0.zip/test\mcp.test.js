import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/client";
import { StdioClientTransport } from "@modelcontextprotocol/client/stdio";

test("MCP server initializes, lists tools, and executes a local tool", async (context) => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "siglent-mcp-"));
  const serverFile = fileURLToPath(new URL("../src/server.js", import.meta.url));
  const client = new Client({ name: "test-client", version: "1.0.0" });
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [serverFile],
    env: { ...process.env, SIGLENT_DATA_DIR: directory }
  });
  context.after(async () => {
    await client.close();
    await fs.rm(directory, { recursive: true, force: true });
  });
  await client.connect(transport);
  const { tools } = await client.listTools();
  assert.ok(tools.some((tool) => tool.name === "siglent_capture_analyze"));
  assert.ok(tools.some((tool) => tool.name === "siglent_monitor"));
  const result = await client.callTool({ name: "siglent_list_devices", arguments: {} });
  assert.equal(result.isError, undefined);
  assert.equal(result.content[0].text, "[]");
});
