import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const DATA_DIR = process.env.SIGLENT_DATA_DIR
  ? path.resolve(process.env.SIGLENT_DATA_DIR)
  : path.join(os.homedir(), ".siglent-scope-mcp");

export const DEFAULT_CONFIG = Object.freeze({
  port: 5025,
  connectTimeoutMs: 1200,
  commandTimeoutMs: 10000,
  discoveryTimeoutMs: 250,
  discoveryConcurrency: 48,
  allowWrite: false,
  allowPublicHosts: false,
  allowedHosts: [],
  restoreAfterCapture: true,
  maxWaveformBytes: 256 * 1024 * 1024,
  maxWaveformPoints: 25_000_000,
  maxDiscoveryHosts: 1024
});

export function getConfig(overrides = {}) {
  return { ...DEFAULT_CONFIG, ...overrides };
}
