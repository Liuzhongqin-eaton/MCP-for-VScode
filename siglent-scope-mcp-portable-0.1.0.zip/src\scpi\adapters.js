import { assertChannel, assertFiniteNumber } from "../util.js";

function parseIdn(idn) {
  const [manufacturer = "", model = "", serial = "", firmware = ""] =
    idn.split(",").map((part) => part.trim());
  return { manufacturer, model, serial, firmware, raw: idn };
}

function numeric(response) {
  const match = String(response).match(/[-+]?\d*\.?\d+(?:e[-+]?\d+)?/i);
  if (!match) throw new Error(`Expected numeric SCPI response, received: ${response}`);
  return Number(match[0]);
}

function boolResponse(response) {
  return /\b(ON|1)\b/i.test(response);
}

function commandFromQuery(command, response) {
  const trimmed = response.trim();
  return trimmed.toUpperCase().startsWith(`${command.toUpperCase()} `)
    ? trimmed
    : `${command} ${trimmed}`;
}

function scalarValue(response) {
  return response.trim().split(/\s+/).at(-1);
}

function legacySlope(value) {
  const normalized = String(value).toUpperCase();
  if (["POS", "POSITIVE", "RISING", "RISE"].includes(normalized)) return "POS";
  if (["NEG", "NEGATIVE", "FALLING", "FALL"].includes(normalized)) return "NEG";
  if (normalized === "WINDOW") return "WINDOW";
  throw new Error(`Unsupported legacy trigger slope: ${value}`);
}

function hdSlope(value) {
  const normalized = String(value).toUpperCase();
  if (["POS", "POSITIVE", "RISING", "RISE"].includes(normalized)) return "RISing";
  if (["NEG", "NEGATIVE", "FALLING", "FALL"].includes(normalized)) return "FALLing";
  if (["ALT", "ALTERNATE"].includes(normalized)) return "ALTernate";
  throw new Error(`Unsupported HD trigger slope: ${value}`);
}

export class ScopeAdapter {
  constructor(transport, identity) {
    this.transport = transport;
    this.identity = identity;
  }

  async query(command) {
    return this.transport.queryLine(command);
  }

  async command(command) {
    return this.transport.write(command);
  }

  async getCapabilities() {
    return {
      model: this.identity.model,
      family: this.family,
      channels: 4,
      rawTcpPort: this.transport.port,
      supportsOfflineProtocolDecode: true,
      supportsSequence: this.family === "sds1000x-hd",
      supportsHistory: this.family === "sds1000x-e"
    };
  }
}

export class LegacySds1000XeAdapter extends ScopeAdapter {
  family = "sds1000x-e";

  async getSettings() {
    const channels = [];
    for (let channel = 1; channel <= 4; channel++) {
      channels.push({
        channel,
        enabled: boolResponse(await this.query(`C${channel}:TRA?`)),
        scale: numeric(await this.query(`C${channel}:VDIV?`)),
        offset: numeric(await this.query(`C${channel}:OFST?`)),
        probe: numeric(await this.query(`C${channel}:ATTN?`)),
        coupling: scalarValue(await this.query(`C${channel}:CPL?`)),
        triggerLevel: numeric(await this.query(`C${channel}:TRLV?`)),
        triggerSlope: scalarValue(await this.query(`C${channel}:TRSL?`))
      });
    }
    return {
      channels,
      timeScale: numeric(await this.query("TDIV?")),
      delay: numeric(await this.query("TRDL?")),
      sampleRate: numeric(await this.query("SARA?")),
      memoryDepth: scalarValue(await this.query("MSIZ?")),
      bandwidthState: await this.query("BWL?"),
      triggerSelect: await this.query("TRSE?"),
      triggerMode: await this.query("TRMD?")
    };
  }

  async applySettings(settings) {
    if (settings.timeScale != null) await this.setTimeScale(settings.timeScale);
    if (settings.delay != null) await this.command(`TRDL ${settings.delay}`);
    if (settings.memoryDepth) await this.command(`MSIZ ${settings.memoryDepth}`);
    for (const item of settings.channels ?? []) {
      await this.setChannel(item.channel, item);
    }
    if (settings.bandwidthState) await this.command(commandFromQuery("BWL", settings.bandwidthState));
    if (settings.triggerSelect) await this.command(commandFromQuery("TRSE", settings.triggerSelect));
    if (settings.triggerMode) await this.command(commandFromQuery("TRMD", settings.triggerMode));
    for (const item of settings.channels ?? []) {
      if (item.triggerLevel != null) await this.command(`C${item.channel}:TRLV ${item.triggerLevel}`);
      if (item.triggerSlope) await this.command(`C${item.channel}:TRSL ${item.triggerSlope}`);
    }
  }

  async setChannel(channel, settings) {
    assertChannel(channel);
    if (settings.enabled != null) await this.command(`C${channel}:TRA ${settings.enabled ? "ON" : "OFF"}`);
    if (settings.probe != null) await this.command(`C${channel}:ATTN ${settings.probe}`);
    if (settings.scale != null) await this.command(`C${channel}:VDIV ${settings.scale}`);
    if (settings.offset != null) await this.command(`C${channel}:OFST ${settings.offset}`);
    if (settings.coupling) await this.command(`C${channel}:CPL ${settings.coupling}`);
    if (settings.bandwidthLimit != null) {
      await this.command(`BWL C${channel},${settings.bandwidthLimit ? "ON" : "OFF"}`);
    }
  }

  async setTimeScale(secondsPerDivision) {
    assertFiniteNumber(secondsPerDivision, "secondsPerDivision", { min: 1e-9, max: 100 });
    await this.command(`TDIV ${secondsPerDivision}`);
  }

  async configureEdgeTrigger({ channel = 1, level = 0, slope = "positive", mode = "NORM" }) {
    assertChannel(channel);
    await this.command(`TRSE EDGE,SR,C${channel},HT,OFF`);
    await this.command(`C${channel}:TRLV ${level}`);
    await this.command(`C${channel}:TRSL ${legacySlope(slope)}`);
    await this.command(`TRMD ${mode}`);
  }

  async acquireSingle(timeoutMs = 10000) {
    await this.command("TRMD SINGLE");
    await this.command("ARM");
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const state = await this.query("SAST?");
      if (/STOP|TRIG/i.test(state)) return state;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    throw new Error("Single acquisition timed out");
  }

  async readWaveform(channel) {
    assertChannel(channel);
    const [scaleText, offsetText, sampleRateText, timeScaleText, delayText] = await Promise.all([
      this.query(`C${channel}:VDIV?`),
      this.query(`C${channel}:OFST?`),
      this.query("SARA?"),
      this.query("TDIV?"),
      this.query("TRDL?")
    ]);
    await this.command("CHDR OFF");
    await this.command("WFSU SP,1,NP,0,FP,0");
    const raw = await this.transport.queryBinary(`C${channel}:WF? DAT2`);
    const samples = new Float64Array(raw.length);
    const scale = numeric(scaleText);
    const offset = numeric(offsetText);
    for (let index = 0; index < raw.length; index++) {
      const signed = raw[index] > 127 ? raw[index] - 256 : raw[index];
      samples[index] = signed * scale / 25 - offset;
    }
    const sampleRate = numeric(sampleRateText);
    return {
      channel,
      samples,
      sampleInterval: 1 / sampleRate,
      startTime: -7 * numeric(timeScaleText) + numeric(delayText),
      metadata: { scale, offset, sampleRate, encoding: "int8-dat2", family: this.family }
    };
  }

  async setAcquisitionPlan(plan) {
    await this.setTimeScale(plan.timeScale);
    if (plan.memoryDepth) await this.command(`MSIZ ${plan.memoryDepth}`);
  }

  async getScreenshot() {
    return this.transport.queryBinary("SCDP", { allowRaw: true });
  }
}

function parseHdDescriptor(buffer) {
  if (buffer.length < 0x14a) throw new Error(`HD waveform descriptor is too short: ${buffer.length}`);
  const timeDivisions = [
    200e-12, 500e-12, 1e-9, 2e-9, 5e-9, 10e-9, 20e-9, 50e-9, 100e-9,
    200e-9, 500e-9, 1e-6, 2e-6, 5e-6, 10e-6, 20e-6, 50e-6, 100e-6,
    200e-6, 500e-6, 1e-3, 2e-3, 5e-3, 10e-3, 20e-3, 50e-3, 100e-3,
    200e-3, 500e-3, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000
  ];
  const timeDivisionIndex = buffer.readInt16LE(0x144);
  return {
    triggerTimeLength: buffer.readUInt32LE(0x30),
    sampleCount: buffer.readUInt32LE(0x74),
    segmentCount: buffer.readUInt32LE(0x90),
    verticalScale: buffer.readFloatLE(0x9c),
    verticalOffset: buffer.readFloatLE(0xa0),
    codesPerDivision: buffer.readFloatLE(0xa4),
    adcBits: buffer.readInt16LE(0xac),
    sampleInterval: buffer.readFloatLE(0xb0),
    horizontalDelay: buffer.readDoubleLE(0xb4),
    timeDivisionIndex,
    timeScale: timeDivisions[timeDivisionIndex],
    probeRatio: buffer.readFloatLE(0x148)
  };
}

export class Sds1000XhdAdapter extends ScopeAdapter {
  family = "sds1000x-hd";

  async getSettings() {
    const channels = [];
    for (let channel = 1; channel <= 4; channel++) {
      channels.push({
        channel,
        enabled: boolResponse(await this.query(`:CHANnel${channel}:SWITch?`)),
        scale: numeric(await this.query(`:CHANnel${channel}:SCALe?`)),
        offset: numeric(await this.query(`:CHANnel${channel}:OFFSet?`)),
        probe: numeric(await this.query(`:CHANnel${channel}:PROBe?`)),
        coupling: scalarValue(await this.query(`:CHANnel${channel}:COUPling?`)),
        bandwidthLimit: boolResponse(await this.query(`:CHANnel${channel}:BWLimit?`))
      });
    }
    return {
      channels,
      timeScale: numeric(await this.query(":TIMebase:SCALe?")),
      delay: numeric(await this.query(":TIMebase:DELay?")),
      sampleRate: numeric(await this.query(":ACQuire:SRATe?")),
      memoryDepth: scalarValue(await this.query(":ACQuire:MDEPth?")),
      memoryManagement: scalarValue(await this.query(":ACQuire:MMANagement?")),
      trigger: {
        type: scalarValue(await this.query(":TRIGger:TYPE?")),
        mode: scalarValue(await this.query(":TRIGger:MODE?")),
        source: scalarValue(await this.query(":TRIGger:EDGE:SOURce?")),
        level: numeric(await this.query(":TRIGger:EDGE:LEVel?")),
        slope: scalarValue(await this.query(":TRIGger:EDGE:SLOPe?"))
      }
    };
  }

  async applySettings(settings) {
    if (settings.timeScale != null) await this.setTimeScale(settings.timeScale);
    if (settings.delay != null) await this.command(`:TIMebase:DELay ${settings.delay}`);
    if (settings.memoryDepth) {
      await this.command(`:ACQuire:MMANagement ${settings.memoryManagement ?? "FMDepth"}`);
      await this.command(`:ACQuire:MDEPth ${settings.memoryDepth}`);
    }
    for (const item of settings.channels ?? []) {
      await this.setChannel(item.channel, item);
    }
    if (settings.trigger) {
      await this.command(commandFromQuery(":TRIGger:TYPE", settings.trigger.type));
      await this.command(commandFromQuery(":TRIGger:EDGE:SOURce", settings.trigger.source));
      await this.command(`:TRIGger:EDGE:LEVel ${settings.trigger.level}`);
      await this.command(commandFromQuery(":TRIGger:EDGE:SLOPe", settings.trigger.slope));
      await this.command(commandFromQuery(":TRIGger:MODE", settings.trigger.mode));
    }
  }

  async setChannel(channel, settings) {
    assertChannel(channel);
    if (settings.enabled != null) await this.command(`:CHANnel${channel}:SWITch ${settings.enabled ? "ON" : "OFF"}`);
    if (settings.probe != null) await this.command(`:CHANnel${channel}:PROBe ${settings.probe}`);
    if (settings.scale != null) await this.command(`:CHANnel${channel}:SCALe ${settings.scale}`);
    if (settings.offset != null) await this.command(`:CHANnel${channel}:OFFSet ${settings.offset}`);
    if (settings.coupling) await this.command(`:CHANnel${channel}:COUPling ${settings.coupling}`);
    if (settings.bandwidthLimit != null) {
      await this.command(`:CHANnel${channel}:BWLimit ${settings.bandwidthLimit ? "ON" : "OFF"}`);
    }
  }

  async setTimeScale(secondsPerDivision) {
    assertFiniteNumber(secondsPerDivision, "secondsPerDivision", { min: 1e-9, max: 100 });
    await this.command(`:TIMebase:SCALe ${secondsPerDivision}`);
  }

  async configureEdgeTrigger({ channel = 1, level = 0, slope = "positive", mode = "NORMal" }) {
    assertChannel(channel);
    await this.command(":TRIGger:TYPE EDGE");
    await this.command(`:TRIGger:EDGE:SOURce C${channel}`);
    await this.command(`:TRIGger:EDGE:LEVel ${level}`);
    await this.command(`:TRIGger:EDGE:SLOPe ${hdSlope(slope)}`);
    await this.command(`:TRIGger:MODE ${mode}`);
  }

  async acquireSingle(timeoutMs = 10000) {
    await this.command(":TRIGger:MODE SINGle");
    await this.command(":TRIGger:RUN");
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const state = await this.query(":TRIGger:STATus?");
      if (/STOP|TRIG/i.test(state)) return state;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    throw new Error("Single acquisition timed out");
  }

  async readWaveform(channel) {
    assertChannel(channel);
    await this.command(`:WAVeform:SOURce C${channel}`);
    await this.command(":WAVeform:WIDTh WORD");
    const descriptor = parseHdDescriptor(await this.transport.queryBinary(":WAVeform:PREamble?"));
    if (!Number.isFinite(descriptor.timeScale)) {
      throw new Error(`Unsupported HD time-division index: ${descriptor.timeDivisionIndex}`);
    }
    if (descriptor.sampleCount > this.transport.config.maxWaveformPoints) {
      throw new Error(
        `Waveform has ${descriptor.sampleCount} points; configured safety limit is ` +
        `${this.transport.config.maxWaveformPoints}`
      );
    }
    const maxPoints = numeric(await this.query(":WAVeform:MAXPoint?"));
    await this.command(":WAVeform:INTerval 1");
    const samples = new Float64Array(descriptor.sampleCount);
    const probe = descriptor.probeRatio || 1;
    const voltsPerDivision = descriptor.verticalScale * probe;
    const offset = descriptor.verticalOffset * probe;
    let receivedPoints = 0;
    while (receivedPoints < descriptor.sampleCount) {
      const requestedPoints = Math.min(maxPoints, descriptor.sampleCount - receivedPoints);
      await this.command(`:WAVeform:STARt ${receivedPoints}`);
      await this.command(`:WAVeform:POINt ${requestedPoints}`);
      const raw = await this.transport.queryBinary(":WAVeform:DATA?");
      const chunkPoints = Math.min(requestedPoints, Math.floor(raw.length / 2));
      if (chunkPoints === 0) throw new Error(`HD waveform transfer stopped at point ${receivedPoints}`);
      for (let index = 0; index < chunkPoints; index++) {
        samples[receivedPoints + index] = raw.readInt16LE(index * 2) /
          descriptor.codesPerDivision * voltsPerDivision - offset;
      }
      receivedPoints += chunkPoints;
    }
    return {
      channel,
      samples,
      sampleInterval: descriptor.sampleInterval,
      startTime: descriptor.horizontalDelay - 5 * descriptor.timeScale,
      metadata: {
        ...descriptor,
        sampleRate: 1 / descriptor.sampleInterval,
        encoding: "int16-le",
        family: this.family
      }
    };
  }

  async setAcquisitionPlan(plan) {
    await this.setTimeScale(plan.timeScale);
    await this.command(":ACQuire:MMANagement FMDepth");
    await this.command(`:ACQuire:MDEPth ${plan.memoryDepth}`);
  }

  async configureSequence(count) {
    assertFiniteNumber(count, "count", { min: 1, max: 100000 });
    await this.command(":TRIGger:STOP");
    await this.command(":ACQuire:SEQuence ON");
    await this.command(`:ACQuire:SEQuence:COUNt ${Math.floor(count)}`);
  }

  async getScreenshot() {
    return this.transport.queryBinary(":PRINt? PNG", { allowRaw: true });
  }
}

export async function identifyScope(transport) {
  const identity = parseIdn(await transport.queryLine("*IDN?"));
  const normalized = identity.model.toUpperCase().replaceAll(/[\s-]/g, "");
  if (normalized.includes("SDS1204XHD") || normalized.includes("SDS1000XHD")) {
    return new Sds1000XhdAdapter(transport, identity);
  }
  if (normalized.includes("SDS1204XE") || normalized.includes("SDS1000XE")) {
    return new LegacySds1000XeAdapter(transport, identity);
  }
  throw new Error(`Unsupported Siglent model: ${identity.model || identity.raw}`);
}

export const adapterInternals = { parseIdn, numeric, parseHdDescriptor };
