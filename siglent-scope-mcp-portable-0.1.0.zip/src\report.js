import fs from "node:fs/promises";
import path from "node:path";
import { escapeHtml, timestampId } from "./util.js";

function findingRows(findings) {
  return findings.map((finding) => `<tr>
    <td>${escapeHtml(finding.severity)}</td>
    <td>${escapeHtml(finding.code)}</td>
    <td>${Math.round((finding.confidence ?? 0) * 100)}%</td>
    <td>${escapeHtml(finding.explanation)}</td>
    <td><pre>${escapeHtml(JSON.stringify(finding.evidence, null, 2))}</pre></td>
    <td>${escapeHtml((finding.alternatives ?? []).join("; "))}</td>
  </tr>`).join("\n");
}

function waveformSvg(preview, width = 900, height = 240) {
  if (!preview?.length) return "<p>No waveform preview available.</p>";
  const values = preview.map((point) => point.value);
  const minimum = Math.min(...values);
  const maximum = Math.max(...values);
  const span = Math.max(maximum - minimum, Number.EPSILON);
  const points = preview.map((point, index) => {
    const x = index / Math.max(preview.length - 1, 1) * width;
    const y = height - (point.value - minimum) / span * height;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Waveform preview">
    <rect width="100%" height="100%" fill="#071b2b"/>
    <polyline fill="none" stroke="#38e07b" stroke-width="2" points="${points}"/>
  </svg>`;
}

export async function writeReport(result, outputDirectory) {
  await fs.mkdir(outputDirectory, { recursive: true });
  const id = result.id ?? timestampId("report");
  const jsonFile = path.join(outputDirectory, `${id}.json`);
  const htmlFile = path.join(outputDirectory, `${id}.html`);
  await fs.writeFile(jsonFile, JSON.stringify(result, null, 2), "utf8");
  const waveforms = Object.entries(result.waveforms ?? {}).map(([name, waveform]) =>
    `<section><h3>${escapeHtml(name)}</h3>${waveformSvg(waveform.preview)}</section>`).join("\n");
  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>${escapeHtml(id)} - Siglent analysis</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:2rem;color:#17212b}table{border-collapse:collapse;width:100%}
th,td{border:1px solid #ccd5df;padding:.5rem;vertical-align:top}th{background:#eef3f7}
pre{white-space:pre-wrap;margin:0}svg{max-width:100%;border-radius:4px}.meta{background:#f5f7f9;padding:1rem}
</style></head><body>
<h1>Siglent Waveform Analysis</h1>
<div class="meta"><strong>Capture:</strong> ${escapeHtml(result.captureId ?? id)}<br>
<strong>Created:</strong> ${escapeHtml(result.createdAt)}<br>
<strong>Instrument:</strong> ${escapeHtml(result.instrument?.model ?? "offline")}</div>
<h2>Findings</h2><table><thead><tr><th>Severity</th><th>Code</th><th>Confidence</th>
<th>Explanation</th><th>Evidence</th><th>Alternatives</th></tr></thead>
<tbody>${findingRows(result.findings ?? [])}</tbody></table>
<h2>Waveforms</h2>${waveforms}
<h2>Protocol result</h2><pre>${escapeHtml(JSON.stringify(result.protocol, null, 2))}</pre>
<h2>Settings</h2><pre>${escapeHtml(JSON.stringify(result.settings, null, 2))}</pre>
</body></html>`;
  await fs.writeFile(htmlFile, html, "utf8");
  return { id, jsonFile, htmlFile };
}
