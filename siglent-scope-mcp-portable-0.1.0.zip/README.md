# Siglent Scope MCP

Local, evidence-based automation for Siglent SDS1204X-E and SDS1204X HD oscilloscopes over raw TCP SCPI (port 5025).

## Features

- Private-LAN discovery and persistent device registry
- Automatic `*IDN?` routing to legacy SDS1000X-E or SDS1000X HD SCPI
- Read-only default, explicit per-device write permission, audit log, and setting restoration
- Raw binary waveform capture and persistent software segments
- Automatic timebase/memory-depth planning from protocol rate
- Measurements, signal-quality findings, confidence, evidence, and alternative causes
- Offline SPI, I2C/IIC, and UART decoding without an oscilloscope protocol license
- Named baselines, normal/abnormal labels, and learned project rules
- Continuous monitoring with stop-on-anomaly
- JSON/JSONL/CSV event correlation for serial, CAN, and firmware logs
- JSON and self-contained HTML reports
- JSON batch scenarios for regression testing
- MCP tools plus a Copilot skill

PDF output is intentionally not required in the first version; HTML can be printed to PDF from a browser.

## Install

### Company computer / cloud-synced copy

Keep this folder in a private synced drive or private repository. On every computer that is physically connected to the oscilloscope LAN, open PowerShell in the project and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install-local.ps1
```

The installer detects Node.js, installs locked dependencies, runs the tests, merges the MCP entry without deleting other servers, and installs the user-level skill. It creates `.siglent-backup` copies before changing existing MCP configuration files.

The workspace also contains `.vscode\mcp.json`, which uses `${workspaceFolder}` and therefore works without a fixed drive letter after dependencies are installed.

VS Code Settings Sync can synchronize MCP configuration when **Settings Sync: Configure > MCP Servers** is enabled. It does not copy this program or grant access to the company LAN, so the synced project and local installation are still required.

Do not expose TCP port 5025 to the internet. The local MCP process must run on a company computer that can directly reach the scope's private IP.

### Manual development install

```powershell
npm install
npm test
```

Start the MCP server:

```powershell
npm start
```

Data is stored under `%USERPROFILE%\\.siglent-scope-mcp` unless `SIGLENT_DATA_DIR` is set.

## Safe first use

1. Connect the PC and scope to the same private network.
2. Enable the scope's LAN/VXI-11 or socket service and confirm its IP.
3. Discover or register the scope with write access disabled.
4. Inspect settings and capture using the existing setup.
5. Only enable write access when automatic setup is needed:

```text
siglent_register(host: "192.168.1.100", allowWrite: true)
```

Automatic capture still requires `allowWrite: true` in that individual request. Settings are restored afterward by default.

## Protocol examples

SPI channel map:

```json
{
  "chipSelect": 1,
  "clock": 2,
  "miso": 3,
  "mosi": 4
}
```

I2C channel map:

```json
{ "scl": 1, "sda": 2 }
```

UART channel map:

```json
{ "uart": 1 }
```

The analyzer reads raw samples and does not require the optional protocol-decode license in the scope.

## Batch format

See `examples\\spi-batch.json`. Each scenario contains a `request` accepted by `siglent_capture_analyze` and optional expectations for absent/required findings and metric bounds.

## Hardware limitations

- Exact features depend on the model and firmware returned by `*IDN?`.
- SDS1204X-E uses legacy commands and 8-bit `DAT2` waveform transfer.
- SDS1204X HD uses hierarchical commands and a binary waveform descriptor.
- Four-signal SPI consumes all four analog channels.
- Sampling should be at least 10 samples/symbol for decode and preferably 20–50 for timing-quality analysis.
- SDS1204X-E history is supported by the instrument, while HD sequence acquisition uses a different command family. The current monitor stores each acquisition as a software segment for consistent cross-model behavior.
