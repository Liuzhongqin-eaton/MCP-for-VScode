import dns from "node:dns/promises";
import net from "node:net";

export function assertFiniteNumber(value, name, { min = -Infinity, max = Infinity } = {}) {
  if (!Number.isFinite(value) || value < min || value > max) {
    throw new RangeError(`${name} must be a finite number between ${min} and ${max}`);
  }
}

export function assertChannel(channel) {
  if (!Number.isInteger(channel) || channel < 1 || channel > 4) {
    throw new RangeError("channel must be an integer from 1 to 4");
  }
}

export function isPrivateIp(address) {
  const version = net.isIP(address);
  if (version === 4) {
    const [a, b] = address.split(".").map(Number);
    return a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) || (a === 169 && b === 254);
  }
  if (version === 6) {
    const normalized = address.toLowerCase();
    return normalized === "::1" || normalized.startsWith("fc") ||
      normalized.startsWith("fd") || normalized.startsWith("fe80:");
  }
  return false;
}

export async function assertAllowedHost(host, config) {
  if (typeof host !== "string" || host.length === 0 || host.length > 253) {
    throw new Error("A valid host is required");
  }
  if (config.allowedHosts.includes(host) || config.allowPublicHosts) return;

  const addresses = net.isIP(host)
    ? [{ address: host }]
    : await dns.lookup(host, { all: true });
  if (addresses.length === 0 || addresses.some(({ address }) => !isPrivateIp(address))) {
    throw new Error(`Host ${host} is not private or allowlisted`);
  }
}

export function assertSafeQuery(command) {
  if (typeof command !== "string" || !command.trim().endsWith("?")) {
    throw new Error("Raw SCPI access is read-only and requires a query ending in '?'");
  }
  if (/[\r\n;]/.test(command)) {
    throw new Error("SCPI query must contain exactly one command");
  }
}

export function median(values) {
  if (values.length === 0) return NaN;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function mean(values) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : NaN;
}

export function standardDeviation(values, average = mean(values)) {
  if (values.length < 2) return 0;
  return Math.sqrt(values.reduce((sum, value) => sum + (value - average) ** 2, 0) / values.length);
}

export function percentile(values, p) {
  if (values.length === 0) return NaN;
  const sorted = [...values].sort((a, b) => a - b);
  const index = (sorted.length - 1) * p;
  const lower = Math.floor(index);
  const fraction = index - lower;
  return sorted[lower] + (sorted[Math.min(lower + 1, sorted.length - 1)] - sorted[lower]) * fraction;
}

export function timestampId(prefix = "item") {
  return `${prefix}-${new Date().toISOString().replace(/[:.]/g, "-")}`;
}

export function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
