import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { learnRules, evaluateRules } from "../src/rules.js";
import { correlateEvents } from "../src/correlation.js";
import { writeReport } from "../src/report.js";

test("learned rules flag values outside normal labeled captures", () => {
  const labels = [1000, 1001, 999, 1000.5].map((frequency, index) => ({
    label: "normal",
    captureId: `capture-${index}`,
    channel: "ch1",
    metrics: { frequency }
  }));
  const rules = learnRules(labels);
  const findings = evaluateRules({ frequency: 900 }, rules, "ch1");
  assert.equal(rules.length, 1);
  assert.equal(findings[0].code, "learned-rule-frequency");
});

test("event correlation accepts JSONL logs", async (context) => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "siglent-events-"));
  context.after(() => fs.rm(directory, { recursive: true, force: true }));
  const file = path.join(directory, "firmware.jsonl");
  await fs.writeFile(file, [
    JSON.stringify({ timestamp: "2026-09-05T12:00:00.050Z", message: "IRQ" }),
    JSON.stringify({ timestamp: "2026-09-05T12:00:03.000Z", message: "late" })
  ].join("\n"));
  const events = await correlateEvents({
    captureTimestamp: "2026-09-05T12:00:00.000Z",
    eventFiles: [file],
    windowMs: 100
  });
  assert.equal(events.length, 1);
  assert.equal(events[0].message, "IRQ");
  assert.equal(events[0].deltaMs, 50);
});

test("HTML and JSON reports are generated", async (context) => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "siglent-report-"));
  context.after(() => fs.rm(directory, { recursive: true, force: true }));
  const output = await writeReport({
    id: "test-report",
    createdAt: "2026-09-05T12:00:00Z",
    findings: [{
      code: "example",
      severity: "medium",
      confidence: 0.8,
      explanation: "<evidence>",
      evidence: { value: 1 },
      alternatives: []
    }],
    waveforms: {
      ch1: { preview: [{ value: 0 }, { value: 1 }] }
    }
  }, directory);
  assert.match(await fs.readFile(output.htmlFile, "utf8"), /&lt;evidence&gt;/);
  assert.equal(JSON.parse(await fs.readFile(output.jsonFile, "utf8")).id, "test-report");
});
