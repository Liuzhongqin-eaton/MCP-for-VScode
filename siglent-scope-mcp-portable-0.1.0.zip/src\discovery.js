import net from "node:net";
import os from "node:os";
import { ScpiTransport } from "./scpi/transport.js";
import { identifyScope } from "./scpi/adapters.js";
import { assertAllowedHost, isPrivateIp } from "./util.js";

function subnetCandidates(config) {
  const candidates = new Set();
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const entry of entries ?? []) {
      if (entry.family !== "IPv4" || entry.internal || !isPrivateIp(entry.address)) continue;
      const octets = entry.address.split(".");
      for (let host = 1; host < 255; host++) {
        const address = `${octets[0]}.${octets[1]}.${octets[2]}.${host}`;
        if (address !== entry.address) candidates.add(address);
        if (candidates.size >= config.maxDiscoveryHosts) return [...candidates];
      }
    }
  }
  return [...candidates];
}

async function portOpen(host, port, timeoutMs) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port });
    const finish = (open) => {
      socket.destroy();
      resolve(open);
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => finish(true));
    socket.once("timeout", () => finish(false));
    socket.once("error", () => finish(false));
  });
}

async function mapConcurrent(items, concurrency, worker) {
  const results = [];
  let cursor = 0;
  async function consume() {
    while (cursor < items.length) {
      const item = items[cursor++];
      const value = await worker(item);
      if (value != null) results.push(value);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, consume));
  return results;
}

export async function discoverScopes(config, { hosts, port = 5025 } = {}) {
  const candidates = hosts?.length ? hosts : subnetCandidates(config);
  for (const host of candidates) await assertAllowedHost(host, config);
  const openHosts = await mapConcurrent(candidates, config.discoveryConcurrency, async (host) =>
    await portOpen(host, port, config.discoveryTimeoutMs) ? host : null);

  return mapConcurrent(openHosts, 8, async (host) => {
    const transport = new ScpiTransport(host, { ...config, commandTimeoutMs: 1500 }, { port });
    try {
      const adapter = await identifyScope(transport);
      return {
        host,
        port,
        identity: adapter.identity,
        capabilities: await adapter.getCapabilities(),
        discoveredAt: new Date().toISOString()
      };
    } catch {
      return null;
    } finally {
      transport.close();
    }
  });
}

export const discoveryInternals = { subnetCandidates, portOpen };
