#!/usr/bin/env node
import { McpServer } from "@modelcontextprotocol/server";
import { StdioServerTransport } from "@modelcontextprotocol/server/stdio";
import * as z from "zod/v4";
import { ScopeService } from "./service.js";
import { runBatch } from "./batch.js";
import { correlateEvents } from "./correlation.js";

const service = new ScopeService();
const server = new McpServer({
  name: "siglent-scope-mcp",
  version: "0.1.0"
});

const hostSchema = {
  host: z.string().min(1).describe("Private/allowlisted oscilloscope IP address or hostname"),
  port: z.number().int().min(1).max(65535).default(5025)
};

function response(value) {
  return {
    content: [{
      type: "text",
      text: typeof value === "string" ? value : JSON.stringify(value, null, 2)
    }]
  };
}

function register(name, description, schema, handler) {
  server.registerTool(name, { description, inputSchema: z.object(schema) }, async (input) => {
    try {
      return response(await handler(input));
    } catch (error) {
      return {
        isError: true,
        content: [{ type: "text", text: `${error.name}: ${error.message}` }]
      };
    }
  });
}

register("siglent_discover", "Discover supported Siglent oscilloscopes on private local IPv4 /24 networks or probe specified hosts.", {
  hosts: z.array(z.string()).max(1024).optional(),
  port: z.number().int().min(1).max(65535).default(5025)
}, (input) => service.discover(input));

register("siglent_list_devices", "List locally registered Siglent oscilloscopes and their write-access status.", {},
  () => service.listDevices());

register("siglent_register", "Identify and register a Siglent scope. Write access remains disabled unless explicitly confirmed.", {
  ...hostSchema,
  allowWrite: z.boolean().default(false).describe("Explicitly allow automated SCPI setting changes")
}, (input) => service.register(input));

register("siglent_inspect", "Read identity, capabilities, channels, acquisition, and trigger settings without changing the scope.", {
  ...hostSchema
}, (input) => service.inspect(input));

const captureSchema = {
  ...hostSchema,
  channels: z.array(z.number().int().min(1).max(4)).min(1).max(4).optional(),
  channelMap: z.record(z.string(), z.number().int().min(1).max(4)).default({}),
  protocol: z.enum(["spi", "i2c", "iic", "uart"]).optional(),
  frequency: z.number().positive().optional(),
  baudRate: z.number().positive().optional(),
  frameBits: z.number().int().positive().default(16),
  frames: z.number().int().min(1).max(10000).default(20),
  protocolOptions: z.record(z.string(), z.unknown()).default({}),
  channelSettings: z.record(z.string(), z.record(z.string(), z.unknown())).optional(),
  thresholds: z.record(z.string(), z.number()).optional(),
  tolerances: z.record(z.string(), z.number().nonnegative()).optional(),
  minimumShapeCorrelation: z.number().min(-1).max(1).default(0.9),
  configure: z.boolean().default(false),
  allowWrite: z.boolean().default(false),
  trigger: z.object({
    channel: z.number().int().min(1).max(4).default(1),
    level: z.number().default(0),
    slope: z.string().default("positive"),
    mode: z.string().default("NORM")
  }).optional(),
  baseline: z.string().optional(),
  project: z.string().optional(),
  eventFiles: z.array(z.string()).default([]),
  correlationWindowMs: z.number().positive().default(1000),
  report: z.boolean().default(true),
  reportDirectory: z.string().optional(),
  restore: z.boolean().default(true),
  acquisitionTimeoutMs: z.number().int().positive().max(300000).default(10000)
};

register("siglent_capture_analyze", "Capture raw waveforms, optionally auto-configure the scope, decode SPI/I2C/UART offline, compare baselines/rules, correlate logs, and create evidence-based reports.", captureSchema,
  (input) => service.captureAndAnalyze(input));

register("siglent_monitor", "Continuously capture software segments, persist every segment, and optionally stop on the first anomaly.", {
  ...captureSchema,
  iterations: z.number().int().min(1).max(10000).default(10),
  intervalMs: z.number().int().min(0).max(86400000).default(1000),
  stopOnAnomaly: z.boolean().default(true)
}, (input) => service.monitor(input));

register("siglent_analyze_saved", "Re-run measurements or SPI/I2C/UART decoding on a saved raw capture without reconnecting to the scope.", {
  captureId: z.string(),
  protocol: z.enum(["spi", "i2c", "iic", "uart"]).optional(),
  channelMap: z.record(z.string(), z.number().int().min(1).max(4)).default({}),
  protocolOptions: z.record(z.string(), z.unknown()).default({}),
  frequency: z.number().positive().optional(),
  baudRate: z.number().positive().optional(),
  thresholds: z.record(z.string(), z.number()).optional(),
  report: z.boolean().default(true),
  reportDirectory: z.string().optional()
}, (input) => service.analyzeSavedCapture(input));

register("siglent_save_baseline", "Save the measurements from a capture as a named normal baseline.", {
  captureId: z.string(),
  name: z.string().min(1)
}, (input) => service.saveBaseline(input));

register("siglent_label_capture", "Label a saved capture as normal or abnormal for a project rule library.", {
  captureId: z.string(),
  project: z.string().min(1),
  label: z.enum(["normal", "abnormal"]),
  notes: z.string().default("")
}, (input) => service.labelCapture(input));

register("siglent_learn_rules", "Learn per-metric normal ranges from at least three normal labeled captures.", {
  project: z.string().min(1)
}, ({ project }) => service.learnProjectRules(project));

register("siglent_run_batch", "Run capture-and-analysis regression scenarios from a JSON batch file.", {
  batchFile: z.string()
}, ({ batchFile }) => runBatch(service, batchFile));

register("siglent_correlate_logs", "Correlate a capture timestamp with JSON, JSONL, CSV, serial, CAN, or firmware event logs.", {
  captureTimestamp: z.union([z.string(), z.number()]),
  eventFiles: z.array(z.string()).min(1),
  windowMs: z.number().positive().default(1000)
}, (input) => correlateEvents(input));

register("siglent_raw_query", "Run one read-only SCPI query. Commands that write, contain separators, or lack '?' are rejected.", {
  ...hostSchema,
  command: z.string().min(2)
}, (input) => service.rawQuery(input));

const transport = new StdioServerTransport();
await server.connect(transport);
