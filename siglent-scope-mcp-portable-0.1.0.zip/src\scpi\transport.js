import net from "node:net";
import { assertAllowedHost } from "../util.js";

export class ScpiTransport {
  constructor(host, config, { port = config.port } = {}) {
    this.host = host;
    this.port = port;
    this.config = config;
    this.socket = null;
    this.buffer = Buffer.alloc(0);
    this.waiters = [];
    this.chain = Promise.resolve();
  }

  async connect() {
    await assertAllowedHost(this.host, this.config);
    if (this.socket && !this.socket.destroyed) return;
    this.socket = net.createConnection({ host: this.host, port: this.port });
    this.socket.setNoDelay(true);
    this.socket.on("data", (chunk) => {
      this.buffer = Buffer.concat([this.buffer, chunk]);
      this.#flushWaiters();
    });
    this.socket.on("error", (error) => this.#rejectWaiters(error));
    this.socket.on("close", () => this.#rejectWaiters(new Error("SCPI socket closed")));
    await this.#withTimeout(new Promise((resolve, reject) => {
      this.socket.once("connect", resolve);
      this.socket.once("error", reject);
    }), this.config.connectTimeoutMs, `Connection to ${this.host}:${this.port} timed out`);
  }

  close() {
    this.socket?.destroy();
    this.socket = null;
  }

  async write(command) {
    if (!this.socket || this.socket.destroyed) await this.connect();
    const payload = Buffer.isBuffer(command)
      ? command
      : Buffer.from(`${command.replace(/[\r\n]+$/, "")}\n`, "ascii");
    await new Promise((resolve, reject) => {
      this.socket.write(payload, (error) => error ? reject(error) : resolve());
    });
  }

  queryLine(command) {
    return this.#serialized(async () => {
      await this.write(command);
      const data = await this.#readUntil(Buffer.from("\n"), this.config.commandTimeoutMs);
      return data.toString("utf8").replace(/[\r\n]+$/, "").trim();
    });
  }

  queryBinary(command, { allowRaw = false } = {}) {
    return this.#serialized(async () => {
      await this.write(command);
      if (allowRaw) {
        return this.#readUntilIdle(this.config.commandTimeoutMs, 150);
      }
      return this.#readIeeeBlock(this.config.commandTimeoutMs);
    });
  }

  #serialized(operation) {
    const result = this.chain.then(operation, operation);
    this.chain = result.catch(() => {});
    return result;
  }

  async #readIeeeBlock(timeoutMs) {
    const hash = await this.#readUntil(Buffer.from("#"), timeoutMs);
    if (hash.length > 128) throw new Error("Invalid IEEE block prefix");
    const digits = Number((await this.#readExact(1, timeoutMs)).toString("ascii"));
    if (!Number.isInteger(digits) || digits < 1 || digits > 9) {
      throw new Error("Invalid IEEE block length digit");
    }
    const sizeText = (await this.#readExact(digits, timeoutMs)).toString("ascii");
    const size = Number(sizeText);
    if (!Number.isSafeInteger(size) || size < 0 || size > this.config.maxWaveformBytes) {
      throw new Error(`Invalid or excessive IEEE block size: ${sizeText}`);
    }
    const payload = await this.#readExact(size, timeoutMs);
    await this.#consumeBlockTerminator(Math.min(timeoutMs, 100));
    return payload;
  }

  async #consumeBlockTerminator(timeoutMs) {
    if (this.buffer.length === 0) {
      try {
        await this.#waitForData(timeoutMs);
      } catch (error) {
        if (error.message === "SCPI read timed out") return;
        throw error;
      }
    }
    if (this.buffer[0] === 0x0d) this.buffer = this.buffer.subarray(1);
    if (this.buffer[0] === 0x0a) this.buffer = this.buffer.subarray(1);
  }

  async #readUntil(delimiter, timeoutMs) {
    while (true) {
      const index = this.buffer.indexOf(delimiter);
      if (index >= 0) {
        const end = index + delimiter.length;
        const result = this.buffer.subarray(0, end);
        this.buffer = this.buffer.subarray(end);
        return result;
      }
      await this.#waitForData(timeoutMs);
    }
  }

  async #readExact(size, timeoutMs) {
    while (this.buffer.length < size) await this.#waitForData(timeoutMs);
    const result = this.buffer.subarray(0, size);
    this.buffer = this.buffer.subarray(size);
    return result;
  }

  async #readUntilIdle(timeoutMs, idleMs) {
    await this.#waitForData(timeoutMs);
    while (true) {
      try {
        await this.#waitForData(idleMs);
      } catch (error) {
        if (error.message === "SCPI read timed out") {
          const result = this.buffer;
          this.buffer = Buffer.alloc(0);
          return result;
        }
        throw error;
      }
    }
  }

  #waitForData(timeoutMs) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const index = this.waiters.findIndex((waiter) => waiter.resolve === resolve);
        if (index >= 0) this.waiters.splice(index, 1);
        reject(new Error("SCPI read timed out"));
      }, timeoutMs);
      this.waiters.push({
        resolve: () => {
          clearTimeout(timer);
          resolve();
        },
        reject: (error) => {
          clearTimeout(timer);
          reject(error);
        }
      });
    });
  }

  #flushWaiters() {
    const waiters = this.waiters.splice(0);
    for (const waiter of waiters) waiter.resolve();
  }

  #rejectWaiters(error) {
    const waiters = this.waiters.splice(0);
    for (const waiter of waiters) waiter.reject(error);
  }

  #withTimeout(promise, timeoutMs, message) {
    let timer;
    return Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(message)), timeoutMs);
      })
    ]).finally(() => clearTimeout(timer));
  }
}
