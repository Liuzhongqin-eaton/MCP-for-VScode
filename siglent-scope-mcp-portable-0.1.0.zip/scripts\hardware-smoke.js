import { ScopeService } from "../src/service.js";

const host = process.env.SIGLENT_HOST;
if (!host) {
  console.error("Set SIGLENT_HOST to the oscilloscope IP address.");
  process.exitCode = 2;
} else {
  const service = new ScopeService();
  const result = await service.inspect({
    host,
    port: Number(process.env.SIGLENT_PORT ?? 5025)
  });
  console.log(JSON.stringify(result, null, 2));
}
