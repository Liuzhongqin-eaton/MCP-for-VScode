import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { ScopeService } from "../src/service.js";
import { Store } from "../src/storage.js";
import { getConfig } from "../src/config.js";

function ieeeBlock(data) {
  const length = String(data.length);
  return Buffer.concat([Buffer.from(`#${length.length}${length}`, "ascii"), data, Buffer.from("\n")]);
}

async function fakeLegacyScope() {
  const raw = Buffer.alloc(2000);
  for (let index = 0; index < raw.length; index++) {
    raw[index] = index % 100 < 50 ? 25 : 231;
  }
  const commands = [];
  const server = net.createServer((socket) => {
    let input = "";
    socket.on("data", (chunk) => {
      input += chunk.toString("ascii");
      let newline;
      while ((newline = input.indexOf("\n")) >= 0) {
        const command = input.slice(0, newline).trim();
        input = input.slice(newline + 1);
        commands.push(command);
        const upper = command.toUpperCase();
        let response = null;
        if (upper === "*IDN?") response = "Siglent Technologies,SDS1204X-E,TEST123,8.1.1.2\n";
        else if (/^C[1-4]:TRA\?$/.test(upper)) response = "ON\n";
        else if (/^C[1-4]:VDIV\?$/.test(upper)) response = "1\n";
        else if (/^C[1-4]:OFST\?$/.test(upper)) response = "0\n";
        else if (/^C[1-4]:ATTN\?$/.test(upper)) response = "1\n";
        else if (/^C[1-4]:CPL\?$/.test(upper)) response = "D1M\n";
        else if (/^C[1-4]:TRLV\?$/.test(upper)) response = "0\n";
        else if (/^C[1-4]:TRSL\?$/.test(upper)) response = "POS\n";
        else if (upper === "TDIV?") response = "0.00001\n";
        else if (upper === "TRDL?") response = "0\n";
        else if (upper === "SARA?") response = "100000000\n";
        else if (upper === "MSIZ?") response = "14K\n";
        else if (upper === "BWL?") response = "C1,OFF,C2,OFF,C3,OFF,C4,OFF\n";
        else if (upper === "TRSE?") response = "EDGE,SR,C1,HT,OFF\n";
        else if (upper === "TRMD?") response = "NORM\n";
        else if (upper === "SAST?") response = "STOP\n";
        else if (/^C[1-4]:WF\? DAT2$/.test(upper)) response = ieeeBlock(raw);
        if (response) socket.write(response);
      }
    });
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  return {
    server,
    commands,
    port: server.address().port,
    close: () => new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()))
  };
}

test("service identifies a legacy scope and persists raw capture", async (context) => {
  const fake = await fakeLegacyScope();
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "siglent-test-"));
  context.after(async () => {
    await fake.close();
    await fs.rm(directory, { recursive: true, force: true });
  });
  const service = new ScopeService({
    config: getConfig({
      connectTimeoutMs: 1000,
      commandTimeoutMs: 1000,
      allowedHosts: ["127.0.0.1"]
    }),
    store: new Store(directory)
  });
  const inspected = await service.inspect({ host: "127.0.0.1", port: fake.port });
  assert.equal(inspected.identity.model, "SDS1204X-E");
  assert.equal(inspected.capabilities.family, "sds1000x-e");
  const result = await service.captureAndAnalyze({
    host: "127.0.0.1",
    port: fake.port,
    channels: [1, 2],
    frequency: 1e6,
    report: false
  });
  assert.equal(result.instrument.model, "SDS1204X-E");
  assert.equal(result.metrics.ch1.sampleCount, 2000);
  assert.equal(result.metrics.ch2.sampleCount, 2000);
  assert.ok(Math.abs(result.metrics.ch1.frequency - 1e6) < 1);
  const loaded = await service.store.loadCapture(result.captureId);
  assert.equal(loaded.waveforms.ch1.samples.length, 2000);
  assert.ok(fake.commands.includes("C1:WF? DAT2"));
});
