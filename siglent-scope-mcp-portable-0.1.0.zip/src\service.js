import path from "node:path";
import { getConfig } from "./config.js";
import { ScpiTransport } from "./scpi/transport.js";
import { identifyScope } from "./scpi/adapters.js";
import { discoverScopes } from "./discovery.js";
import { Store } from "./storage.js";
import { planAcquisition } from "./acquisition.js";
import { measureWaveform, serializeWaveform } from "./analysis/waveform.js";
import { analyzeSignalQuality, compareToBaseline, compareWaveformShape } from "./analysis/quality.js";
import { decodeProtocol } from "./analysis/protocols.js";
import { evaluateRules, learnRules } from "./rules.js";
import { correlateEvents } from "./correlation.js";
import { writeReport } from "./report.js";
import { assertSafeQuery, timestampId } from "./util.js";

function mapWaveformsByRole(channelMap, byChannel) {
  return Object.fromEntries(Object.entries(channelMap).map(([role, channel]) => {
    const waveform = byChannel[`ch${channel}`];
    if (!waveform) throw new Error(`No waveform captured for ${role} on channel ${channel}`);
    return [role, waveform];
  }));
}

function primaryRate(request) {
  return request.frequency ?? request.baudRate;
}

export class ScopeService {
  constructor({ config = getConfig(), store = new Store() } = {}) {
    this.config = config;
    this.store = store;
  }

  async discover(options = {}) {
    const devices = await discoverScopes(this.config, options);
    for (const device of devices) await this.store.upsertDevice(device);
    return devices;
  }

  async register({ host, port = 5025, allowWrite = false }) {
    const { adapter, transport } = await this.#connect(host, port);
    try {
      const record = await this.store.upsertDevice({
        host,
        port,
        allowWrite,
        identity: adapter.identity,
        capabilities: await adapter.getCapabilities()
      });
      await this.store.audit({ action: "register", host, port, allowWrite, model: adapter.identity.model });
      return record;
    } finally {
      transport.close();
    }
  }

  async inspect({ host, port = 5025 }) {
    const { adapter, transport } = await this.#connect(host, port);
    try {
      return {
        identity: adapter.identity,
        capabilities: await adapter.getCapabilities(),
        settings: await adapter.getSettings()
      };
    } finally {
      transport.close();
    }
  }

  async rawQuery({ host, port = 5025, command }) {
    assertSafeQuery(command);
    const transport = new ScpiTransport(host, this.config, { port });
    try {
      await transport.connect();
      const response = await transport.queryLine(command);
      await this.store.audit({ action: "raw-query", host, port, command });
      return response;
    } finally {
      transport.close();
    }
  }

  async captureAndAnalyze(request) {
    const {
      host,
      port = 5025,
      channels,
      channelMap = {},
      protocol,
      protocolOptions = {},
      configure = false,
      trigger,
      baseline,
      project,
      eventFiles = [],
      restore = true
    } = request;
    const requestedChannels = [...new Set(channels ?? Object.values(channelMap))];
    if (!requestedChannels.length) throw new Error("At least one channel is required");
    const { adapter, transport } = await this.#connect(host, port);
    let snapshot;
    let primaryError;
    try {
      snapshot = await adapter.getSettings();
      if (configure) {
        await this.#assertWriteEnabled(host, port, request.allowWrite);
        const rate = primaryRate(request);
        if (!rate) throw new Error("frequency or baudRate is required for automatic setup");
        const plan = planAcquisition({
          signalRate: rate,
          protocol,
          frameBits: request.frameBits,
          frames: request.frames,
          family: adapter.family,
          activeChannels: requestedChannels.length,
          sharedAdc: adapter.family === "sds1000x-e" && (
            (requestedChannels.includes(1) && requestedChannels.includes(2)) ||
            (requestedChannels.includes(3) && requestedChannels.includes(4))
          ),
          qualityAnalysis: true
        });
        await adapter.setAcquisitionPlan(plan);
        for (const channel of requestedChannels) {
          await adapter.setChannel(channel, { enabled: true, ...(request.channelSettings?.[`ch${channel}`] ?? {}) });
        }
        if (trigger) await adapter.configureEdgeTrigger(trigger);
        await adapter.acquireSingle(request.acquisitionTimeoutMs);
      }

      const waveforms = {};
      for (const channel of requestedChannels) {
        waveforms[`ch${channel}`] = await adapter.readWaveform(channel);
      }
      const metrics = Object.fromEntries(Object.entries(waveforms).map(([name, waveform]) =>
        [name, measureWaveform(waveform, { threshold: request.thresholds?.[name] })]));
      const findings = Object.entries(metrics).flatMap(([name, values]) =>
        analyzeSignalQuality(values, request).map((finding) => ({
          ...finding,
          evidence: { channel: name, ...finding.evidence }
        })));
      let protocolResult = null;
      if (protocol) {
        protocolResult = decodeProtocol(protocol, mapWaveformsByRole(channelMap, waveforms), {
          ...protocolOptions,
          frequency: request.frequency ?? protocolOptions.frequency,
          baudRate: request.baudRate ?? protocolOptions.baudRate
        });
        findings.push(...protocolResult.findings);
      }
      let baselineResult = null;
      if (baseline) {
        const baselineData = await this.store.loadBaseline(baseline);
        const baselineCapture = baselineData.sourceCapture
          ? await this.store.loadCapture(baselineData.sourceCapture)
          : null;
        baselineResult = {};
        for (const [channel, values] of Object.entries(metrics)) {
          if (baselineData.metrics?.[channel]) {
            baselineResult[channel] = {
              metrics: compareToBaseline(values, baselineData.metrics[channel], request.tolerances),
              shape: baselineCapture?.waveforms?.[channel]
                ? compareWaveformShape(waveforms[channel], baselineCapture.waveforms[channel])
                : null
            };
            baselineResult[channel].passed = baselineResult[channel].metrics.passed &&
              (baselineResult[channel].shape == null ||
                baselineResult[channel].shape.correlation >= (request.minimumShapeCorrelation ?? 0.9));
            if (!baselineResult[channel].passed) {
              findings.push({
                code: "baseline-deviation",
                severity: "medium",
                confidence: 0.9,
                evidence: {
                  channel,
                  differences: baselineResult[channel].metrics.differences,
                  shape: baselineResult[channel].shape
                },
                explanation: "Current measurements differ from the selected normal baseline.",
                alternatives: ["Intentional operating-point change", "Probe/setup difference"]
              });
            }
          }
        }
      }
      if (project) {
        const rules = await this.store.loadRules(project);
        for (const [channel, values] of Object.entries(metrics)) {
          findings.push(...evaluateRules(values, rules, channel).map((finding) => ({
            ...finding,
            evidence: { channel, ...finding.evidence }
          })));
        }
      }
      const captureTime = new Date().toISOString();
      const correlatedEvents = eventFiles.length
        ? await correlateEvents({ captureTimestamp: captureTime, eventFiles, windowMs: request.correlationWindowMs })
        : [];
      const id = timestampId("capture");
      const stored = await this.store.saveCapture({
        id,
        createdAt: captureTime,
        instrument: adapter.identity,
        settings: snapshot,
        waveforms,
        metrics,
        findings,
        protocol: protocolResult,
        baseline: baselineResult,
        correlatedEvents
      });
      const result = {
        id,
        captureId: stored.id,
        captureDirectory: stored.directory,
        createdAt: captureTime,
        instrument: adapter.identity,
        settings: snapshot,
        metrics,
        findings,
        protocol: protocolResult,
        baseline: baselineResult,
        correlatedEvents,
        waveforms: Object.fromEntries(Object.entries(waveforms).map(([name, waveform]) =>
          [name, serializeWaveform(waveform)]))
      };
      if (request.report !== false) {
        result.report = await writeReport(result, request.reportDirectory ?? path.join(this.store.root, "reports"));
      }
      await this.store.audit({
        action: "capture-analyze",
        host,
        port,
        model: adapter.identity.model,
        captureId: id,
        configured: configure,
        findings: findings.map((item) => item.code)
      });
      return result;
    } catch (error) {
      primaryError = error;
      error.capturePhase = "capture-or-analysis";
      throw error;
    } finally {
      let restoreError;
      try {
        if (configure && restore && snapshot) {
          await adapter.applySettings(snapshot);
          await this.store.audit({ action: "restore-settings", host, port });
        }
      } catch (error) {
        restoreError = error;
      } finally {
        transport.close();
      }
      if (restoreError) {
        if (primaryError) {
          throw new AggregateError([primaryError, restoreError], "Capture failed and settings restoration also failed");
        }
        throw restoreError;
      }
    }
  }

  async saveBaseline({ captureId, name }) {
    const capture = await this.store.loadCapture(captureId);
    return this.store.saveBaseline(name, {
      name,
      sourceCapture: captureId,
      createdAt: new Date().toISOString(),
      instrument: capture.instrument,
      metrics: capture.metrics
    });
  }

  async analyzeSavedCapture(request) {
    const capture = await this.store.loadCapture(request.captureId);
    const metrics = Object.fromEntries(Object.entries(capture.waveforms).map(([name, waveform]) =>
      [name, measureWaveform(waveform, { threshold: request.thresholds?.[name] })]));
    const findings = Object.entries(metrics).flatMap(([name, values]) =>
      analyzeSignalQuality(values, request).map((finding) => ({
        ...finding,
        evidence: { channel: name, ...finding.evidence }
      })));
    let protocolResult = null;
    if (request.protocol) {
      protocolResult = decodeProtocol(
        request.protocol,
        mapWaveformsByRole(request.channelMap ?? {}, capture.waveforms),
        {
          ...request.protocolOptions,
          frequency: request.frequency ?? request.protocolOptions?.frequency,
          baudRate: request.baudRate ?? request.protocolOptions?.baudRate
        }
      );
      findings.push(...protocolResult.findings);
    }
    const result = {
      id: timestampId("analysis"),
      captureId: request.captureId,
      createdAt: new Date().toISOString(),
      instrument: capture.instrument,
      settings: capture.settings,
      metrics,
      findings,
      protocol: protocolResult,
      waveforms: Object.fromEntries(Object.entries(capture.waveforms).map(([name, waveform]) =>
        [name, serializeWaveform(waveform)]))
    };
    if (request.report !== false) {
      result.report = await writeReport(result, request.reportDirectory ?? path.join(this.store.root, "reports"));
    }
    return result;
  }

  async labelCapture({ captureId, project, label, notes = "" }) {
    if (!["normal", "abnormal"].includes(label)) throw new Error("label must be normal or abnormal");
    const capture = await this.store.loadCapture(captureId);
    const entries = [];
    for (const [channel, metrics] of Object.entries(capture.metrics)) {
      entries.push(await this.store.addLabel({ captureId, project, channel, label, notes, metrics }));
    }
    return entries;
  }

  async learnProjectRules(project) {
    const labels = await this.store.getLabels(project);
    const rules = learnRules(labels);
    return this.store.saveRules(project, rules);
  }

  async monitor(request) {
    const iterations = request.iterations ?? 10;
    const intervalMs = request.intervalMs ?? 1000;
    if (!Number.isInteger(iterations) || iterations < 1 || iterations > 10000) {
      throw new Error("iterations must be an integer from 1 to 10000");
    }

    const runs = [];
    for (let index = 0; index < iterations; index++) {
      const result = await this.captureAndAnalyze({ ...request, report: false });
      const anomalous = result.findings.some((finding) => ["high", "medium"].includes(finding.severity));
      runs.push({
        index,
        captureId: result.captureId,
        createdAt: result.createdAt,
        anomalous,
        findings: result.findings
      });
      if (request.stopOnAnomaly && anomalous) break;
      if (index < iterations - 1) await new Promise((resolve) => setTimeout(resolve, intervalMs));
    }
    return {
      runs,
      anomalyCount: runs.filter((run) => run.anomalous).length,
      stoppedEarly: runs.length < iterations
    };
  }

  async listDevices() {
    return this.store.listDevices();
  }

  async #assertWriteEnabled(host, port, requestAllowsWrite) {
    const devices = await this.store.listDevices();
    const device = devices.find((item) => item.host === host && item.port === port);
    if (requestAllowsWrite !== true || device?.allowWrite !== true) {
      throw new Error("Instrument writes require allowWrite=true and a registry entry with write access enabled");
    }
  }

  async #connect(host, port) {
    const transport = new ScpiTransport(host, this.config, { port });
    try {
      await transport.connect();
      return { transport, adapter: await identifyScope(transport) };
    } catch (error) {
      transport.close();
      throw error;
    }
  }
}
