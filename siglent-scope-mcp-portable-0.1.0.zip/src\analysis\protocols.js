import { digitalEdges, stateAt } from "./waveform.js";
import { median } from "../util.js";

function bitsToNumber(bits, bitOrder = "msb") {
  const ordered = bitOrder === "lsb" ? [...bits].reverse() : bits;
  return ordered.reduce((value, bit) => (value << 1) | bit, 0);
}

function byteHex(value, width = 2) {
  return `0x${value.toString(16).toUpperCase().padStart(width, "0")}`;
}

export function decodeSpi(waveforms, options) {
  const { clock, chipSelect, mosi, miso } = waveforms;
  if (!clock || !chipSelect || (!mosi && !miso)) {
    throw new Error("SPI decoding requires clock, chipSelect, and at least one data waveform");
  }
  const clockEdges = digitalEdges(clock, { threshold: options.clockThreshold });
  const csEdges = digitalEdges(chipSelect, { threshold: options.csThreshold });
  const mosiEdges = mosi ? digitalEdges(mosi, { threshold: options.mosiThreshold }) : null;
  const misoEdges = miso ? digitalEdges(miso, { threshold: options.misoThreshold }) : null;
  const activeState = options.csActiveLow === false ? 1 : 0;
  const leadingType = (options.cpol ?? 0) === 0 ? "rising" : "falling";
  const sampleType = (options.cpha ?? 0) === 0
    ? leadingType
    : (leadingType === "rising" ? "falling" : "rising");
  const wordBits = options.wordBits ?? 8;
  const lastIndex = clock.samples.length - 1;
  const intervals = [];
  let activeStart = csEdges.initialState === activeState ? 0 : null;
  for (const edge of csEdges.edges) {
    if (edge.state === activeState && activeStart == null) activeStart = edge.index;
    if (edge.state !== activeState && activeStart != null) {
      intervals.push([activeStart, edge.index]);
      activeStart = null;
    }
  }
  if (activeStart != null) intervals.push([activeStart, lastIndex]);
  const frames = [];
  const findings = [];
  const timing = {
    minimumSetupTime: null,
    minimumHoldTime: null,
    minimumChipSelectSetupTime: null,
    minimumChipSelectHoldTime: null
  };
  let sampledEdges = 0;
  for (let transaction = 0; transaction < intervals.length; transaction++) {
    const [start, end] = intervals[transaction];
    const sampled = clockEdges.edges.filter((edge) =>
      edge.type === sampleType && edge.index >= start && edge.index < end);
    sampledEdges += sampled.length;
    if (sampled.length) {
      const startTime = clock.startTime + start * clock.sampleInterval;
      const endTime = clock.startTime + end * clock.sampleInterval;
      const csSetup = sampled[0].time - startTime;
      const csHold = endTime - sampled.at(-1).time;
      timing.minimumChipSelectSetupTime = timing.minimumChipSelectSetupTime == null
        ? csSetup : Math.min(timing.minimumChipSelectSetupTime, csSetup);
      timing.minimumChipSelectHoldTime = timing.minimumChipSelectHoldTime == null
        ? csHold : Math.min(timing.minimumChipSelectHoldTime, csHold);
    }
    for (const dataEdges of [mosiEdges, misoEdges].filter(Boolean)) {
      let dataCursor = 0;
      for (const edge of sampled) {
        while (dataCursor < dataEdges.edges.length && dataEdges.edges[dataCursor].index <= edge.index) {
          dataCursor++;
        }
        const previous = dataEdges.edges[dataCursor - 1];
        const next = dataEdges.edges[dataCursor];
        if (previous) {
          const setup = edge.time - previous.time;
          timing.minimumSetupTime = timing.minimumSetupTime == null
            ? setup : Math.min(timing.minimumSetupTime, setup);
        }
        if (next) {
          const hold = next.time - edge.time;
          timing.minimumHoldTime = timing.minimumHoldTime == null
            ? hold : Math.min(timing.minimumHoldTime, hold);
        }
      }
    }
    for (let offset = 0; offset + wordBits <= sampled.length; offset += wordBits) {
      const current = sampled.slice(offset, offset + wordBits).map((edge) => ({
        time: edge.time,
        mosi: mosiEdges ? stateAt(mosiEdges, edge.index) : null,
        miso: misoEdges ? stateAt(misoEdges, edge.index) : null
      }));
      const frame = {
        transaction,
        startTime: current[0].time,
        endTime: current.at(-1).time,
        bits: wordBits
      };
      if (mosiEdges) {
        frame.mosi = bitsToNumber(current.map((item) => item.mosi), options.bitOrder);
        frame.mosiHex = byteHex(frame.mosi, Math.ceil(wordBits / 4));
      }
      if (misoEdges) {
        frame.miso = bitsToNumber(current.map((item) => item.miso), options.bitOrder);
        frame.misoHex = byteHex(frame.miso, Math.ceil(wordBits / 4));
      }
      frames.push(frame);
    }
    const remainder = sampled.length % wordBits;
    if (remainder) {
      findings.push({
        code: "spi-incomplete-word",
        severity: "high",
        confidence: 0.98,
        evidence: { transaction, capturedBits: remainder, expectedBits: wordBits },
        explanation: "Chip select deasserted before a complete SPI word.",
        alternatives: ["Capture boundary truncated the transaction"]
      });
    }
  }
  for (const [metric, minimum, code] of [
    ["minimumSetupTime", options.minimumSetupTime, "spi-setup-time"],
    ["minimumHoldTime", options.minimumHoldTime, "spi-hold-time"],
    ["minimumChipSelectSetupTime", options.minimumChipSelectSetupTime, "spi-cs-setup-time"],
    ["minimumChipSelectHoldTime", options.minimumChipSelectHoldTime, "spi-cs-hold-time"]
  ]) {
    if (Number.isFinite(minimum) && timing[metric] != null && timing[metric] < minimum) {
      findings.push({
        code,
        severity: "high",
        confidence: 0.95,
        evidence: { measured: timing[metric], required: minimum },
        explanation: `${metric} is below the supplied requirement.`,
        alternatives: ["Threshold noise", "Insufficient sample rate"]
      });
    }
  }
  return { protocol: "spi", frames, findings, sampledEdges, timing };
}

export function decodeI2c(waveforms, options = {}) {
  const { scl, sda } = waveforms;
  if (!scl || !sda) throw new Error("I2C decoding requires scl and sda waveforms");
  const sclEdges = digitalEdges(scl, { threshold: options.sclThreshold });
  const sdaEdges = digitalEdges(sda, { threshold: options.sdaThreshold });
  const events = [];
  for (const edge of sdaEdges.edges) {
    if (stateAt(sclEdges, edge.index) === 1) {
      events.push({
        type: edge.type === "falling" ? "START" : "STOP",
        index: edge.index,
        time: edge.time
      });
    }
  }
  const rising = sclEdges.edges.filter((edge) => edge.type === "rising");
  const transactions = [];
  let current = null;
  let eventCursor = 0;
  let preceding = null;
  for (const edge of rising) {
    while (eventCursor < events.length && events[eventCursor].index <= edge.index) {
      preceding = events[eventCursor++];
    }
    if (!preceding || preceding.type !== "START") continue;
    if (!current || preceding.index > current.startIndex) {
      current = { startIndex: preceding.index, startTime: preceding.time, bytes: [], bits: [] };
      transactions.push(current);
    }
    current.bits.push(stateAt(sdaEdges, edge.index));
    if (current.bits.length === 9) {
      const value = bitsToNumber(current.bits.slice(0, 8));
      current.bytes.push({ value, hex: byteHex(value), ack: current.bits[8] === 0, time: edge.time });
      current.bits = [];
    }
  }
  for (const transaction of transactions) {
    const first = transaction.bytes[0];
    if (first) {
      transaction.address = first.value >> 1;
      transaction.direction = first.value & 1 ? "read" : "write";
    }
    transaction.stopTime = events.find((event) =>
      event.index > transaction.startIndex && event.type === "STOP")?.time ?? null;
    delete transaction.startIndex;
  }
  const findings = [];
  const nacks = transactions.flatMap((transaction) =>
    transaction.bytes
      .map((item, index) => ({ ...item, transaction, index }))
      .filter((item) => !item.ack)
      .filter((item) => !(
        item.transaction.direction === "read" &&
        item.index === item.transaction.bytes.length - 1 &&
        item.transaction.stopTime != null
      )));
  if (nacks.length) {
    findings.push({
      code: "i2c-nack",
      severity: "medium",
      confidence: 0.99,
      evidence: { count: nacks.length, firstTimestamp: nacks[0].time },
      explanation: "One or more I2C bytes were not acknowledged.",
      alternatives: ["Expected final-byte NACK during a read", "Wrong address", "Slave not ready"]
    });
  }
  const lowWidths = [];
  for (let index = 1; index < sclEdges.edges.length; index++) {
    if (sclEdges.edges[index - 1].state === 0) {
      lowWidths.push(sclEdges.edges[index].time - sclEdges.edges[index - 1].time);
    }
  }
  const nominalLow = options.frequency ? 0.5 / options.frequency : median(lowWidths);
  const stretches = lowWidths.filter((width) => Number.isFinite(nominalLow) && width > nominalLow * 1.5);
  if (stretches.length) {
    findings.push({
      code: "i2c-clock-stretch",
      severity: "low",
      confidence: 0.9,
      evidence: { count: stretches.length, longest: Math.max(...stretches), nominalLow },
      explanation: "One or more SCL low periods indicate clock stretching.",
      alternatives: ["Intentional slave clock stretching", "Master pause", "Threshold noise"]
    });
  }
  if (sclEdges.edges.length === 0 && sclEdges.initialState === 0) {
    findings.push({
      code: "i2c-scl-stuck-low",
      severity: "high",
      confidence: 0.99,
      evidence: { duration: scl.samples.length * scl.sampleInterval },
      explanation: "SCL remained low for the complete capture.",
      alternatives: ["Capture window missed bus activity", "Incorrect channel mapping"]
    });
  }
  return { protocol: "i2c", transactions, events, findings, clockLowWidths: lowWidths };
}

export function decodeUart(waveform, options) {
  const baudRate = options.baudRate;
  if (!Number.isFinite(baudRate) || baudRate <= 0) throw new Error("UART baudRate must be positive");
  const edges = digitalEdges(waveform, { threshold: options.threshold });
  const idle = options.inverted ? 0 : 1;
  const active = idle ? 0 : 1;
  const bitPeriod = 1 / baudRate;
  const dataBits = options.dataBits ?? 8;
  const parity = options.parity ?? "none";
  const parityBits = parity === "none" ? 0 : 1;
  const stopBits = options.stopBits ?? 1;
  const frameDuration = (1 + dataBits + parityBits + stopBits) * bitPeriod;
  const frames = [];
  const normalizedBitPeriods = [];
  for (let index = 1; index < edges.edges.length; index++) {
    const interval = edges.edges[index].time - edges.edges[index - 1].time;
    const bitCount = Math.max(1, Math.round(interval / bitPeriod));
    normalizedBitPeriods.push(interval / bitCount);
  }
  const measuredBitPeriod = median(normalizedBitPeriods);
  const measuredBaudRate = Number.isFinite(measuredBitPeriod) && measuredBitPeriod > 0
    ? 1 / measuredBitPeriod : null;
  let nextAllowedTime = -Infinity;
  for (const edge of edges.edges) {
    if (edge.state !== active || edge.time < nextAllowedTime) continue;
    const sampleState = (time) => {
      const index = Math.round((time - waveform.startTime) / waveform.sampleInterval);
      if (index < 0 || index >= waveform.samples.length) return null;
      const state = stateAt(edges, index);
      return options.inverted ? 1 - state : state;
    };
    const bits = [];
    for (let bit = 0; bit < dataBits; bit++) {
      bits.push(sampleState(edge.time + (1.5 + bit) * bitPeriod));
    }
    if (bits.includes(null)) break;
    const value = bitsToNumber(bits, "lsb");
    const parityValue = parityBits ? sampleState(edge.time + (1.5 + dataBits) * bitPeriod) : null;
    const ones = bits.reduce((sum, bit) => sum + bit, 0);
    const parityOk = parity === "none" ||
      (parity === "even" ? (ones + parityValue) % 2 === 0 : (ones + parityValue) % 2 === 1);
    const stopStart = 1.5 + dataBits + parityBits;
    let framingOk = true;
    for (let stop = 0; stop < stopBits; stop++) {
      framingOk &&= sampleState(edge.time + (stopStart + stop) * bitPeriod) === 1;
    }
    frames.push({
      startTime: edge.time,
      endTime: edge.time + frameDuration,
      value,
      hex: byteHex(value),
      ascii: value >= 32 && value <= 126 ? String.fromCharCode(value) : ".",
      parityOk,
      framingOk
    });
    nextAllowedTime = edge.time + frameDuration * 0.9;
  }
  const parityErrors = frames.filter((frame) => !frame.parityOk);
  const framingErrors = frames.filter((frame) => !frame.framingOk);
  const findings = [];
  if (parityErrors.length) findings.push({
    code: "uart-parity-error",
    severity: "high",
    confidence: 0.99,
    evidence: { count: parityErrors.length, firstTimestamp: parityErrors[0].startTime },
    explanation: "UART parity validation failed.",
    alternatives: ["Incorrect parity configuration", "Bit error"]
  });
  if (framingErrors.length) findings.push({
    code: "uart-framing-error",
    severity: "high",
    confidence: 0.98,
    evidence: { count: framingErrors.length, firstTimestamp: framingErrors[0].startTime },
    explanation: "The expected UART stop bit was not high.",
    alternatives: ["Incorrect baud rate", "Wrong polarity", "Signal integrity problem"]
  });
  if (measuredBaudRate) {
    const relativeError = Math.abs(measuredBaudRate - baudRate) / baudRate;
    if (relativeError > (options.baudTolerance ?? 0.03)) {
      findings.push({
        code: "uart-baud-rate-deviation",
        severity: relativeError > 0.1 ? "high" : "medium",
        confidence: 0.8,
        evidence: { configured: baudRate, measured: measuredBaudRate, relativeError },
        explanation: "Measured UART edge timing differs from the configured baud rate.",
        alternatives: ["Data pattern has sparse edges", "Clock mismatch", "Incorrect configured baud rate"]
      });
    }
  }
  return { protocol: "uart", frames, findings, measuredBaudRate };
}

export function decodeProtocol(protocol, waveforms, options = {}) {
  switch (protocol.toLowerCase()) {
    case "spi": return decodeSpi(waveforms, options);
    case "i2c":
    case "iic": return decodeI2c(waveforms, options);
    case "uart": return decodeUart(waveforms.uart ?? waveforms.rx ?? Object.values(waveforms)[0], options);
    default: throw new Error(`Unsupported protocol: ${protocol}`);
  }
}
