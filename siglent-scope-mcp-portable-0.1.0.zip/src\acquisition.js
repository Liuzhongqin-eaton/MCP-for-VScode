import { assertFiniteNumber } from "./util.js";

const LEGACY_SHARED_DEPTHS = [
  [7_000, "7K"],
  [70_000, "70K"],
  [700_000, "700K"],
  [7_000_000, "7M"]
];

const LEGACY_INTERLEAVED_DEPTHS = [
  [14_000, "14K"],
  [140_000, "140K"],
  [1_400_000, "1.4M"],
  [14_000_000, "14M"]
];

const HD_DEPTHS = [
  [10_000, "10K"],
  [100_000, "100K"],
  [1_000_000, "1M"],
  [10_000_000, "10M"],
  [25_000_000, "25M"],
  [50_000_000, "50M"],
  [100_000_000, "100M"]
];

function selectDepth(points, family, activeChannels, sharedAdc) {
  const source = family === "sds1000x-hd"
    ? HD_DEPTHS
    : (sharedAdc ? LEGACY_SHARED_DEPTHS : LEGACY_INTERLEAVED_DEPTHS);
  const cappedPoints = family === "sds1000x-hd" && activeChannels >= 3
    ? Math.min(points, 50_000_000)
    : points;
  return (source.find(([count]) => count >= cappedPoints) ?? source.at(-1))[1];
}

export function planAcquisition({
  signalRate,
  protocol = "generic",
  frameBits = 16,
  frames = 20,
  family = "sds1000x-e",
  activeChannels = 1,
  sharedAdc = activeChannels > 2,
  qualityAnalysis = true
}) {
  assertFiniteNumber(signalRate, "signalRate", { min: 0.01, max: 5e9 });
  const samplesPerBit = qualityAnalysis ? 40 : 12;
  const targetSampleRate = signalRate * samplesPerBit;
  const duration = Math.max(frameBits * frames / signalRate, 10 / signalRate);
  const horizontalDivisions = family === "sds1000x-e" ? 14 : 10;
  const timeScale = duration / horizontalDivisions;
  const targetPoints = Math.ceil(duration * targetSampleRate);
  const memoryDepth = selectDepth(targetPoints, family, activeChannels, sharedAdc);
  return {
    protocol,
    targetSampleRate,
    samplesPerBit,
    duration,
    timeScale,
    targetPoints,
    memoryDepth,
    rationale: [
      `${samplesPerBit} samples per bit/clock for ${qualityAnalysis ? "timing-quality" : "protocol"} analysis`,
      `${frames} frames in a ${duration.toExponential(3)} s observation window`,
      `${activeChannels} active channel(s)`
    ]
  };
}
