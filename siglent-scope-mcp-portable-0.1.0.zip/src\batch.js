import fs from "node:fs/promises";

function evaluateExpectations(result, expect = {}) {
  const failures = [];
  const codes = new Set(result.findings.map((finding) => finding.code));
  for (const code of expect.absentFindings ?? []) {
    if (codes.has(code)) failures.push(`Unexpected finding: ${code}`);
  }
  for (const code of expect.requiredFindings ?? []) {
    if (!codes.has(code)) failures.push(`Missing required finding: ${code}`);
  }
  for (const [path, bounds] of Object.entries(expect.metrics ?? {})) {
    const [channel, metric] = path.split(".");
    const value = result.metrics?.[channel]?.[metric];
    if (!Number.isFinite(value)) failures.push(`Metric not found: ${path}`);
    else if (bounds.minimum != null && value < bounds.minimum) {
      failures.push(`${path}=${value} is below ${bounds.minimum}`);
    } else if (bounds.maximum != null && value > bounds.maximum) {
      failures.push(`${path}=${value} is above ${bounds.maximum}`);
    }
  }
  return { passed: failures.length === 0, failures };
}

export async function runBatch(service, batchFile) {
  const batch = JSON.parse(await fs.readFile(batchFile, "utf8"));
  if (!Array.isArray(batch.scenarios)) throw new Error("Batch file must contain a scenarios array");
  const results = [];
  for (const scenario of batch.scenarios) {
    const startedAt = new Date().toISOString();
    try {
      const analysis = await service.captureAndAnalyze(scenario.request);
      results.push({
        name: scenario.name,
        startedAt,
        captureId: analysis.captureId,
        ...evaluateExpectations(analysis, scenario.expect)
      });
    } catch (error) {
      results.push({ name: scenario.name, startedAt, passed: false, failures: [error.message] });
    }
  }
  return {
    name: batch.name,
    createdAt: new Date().toISOString(),
    passed: results.every((item) => item.passed),
    results
  };
}
