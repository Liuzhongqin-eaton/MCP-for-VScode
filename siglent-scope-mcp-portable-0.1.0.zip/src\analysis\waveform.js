import { mean, median, percentile, standardDeviation } from "../util.js";

export function thresholdLevels(samples, explicitThreshold) {
  if (Number.isFinite(explicitThreshold)) {
    return { low: explicitThreshold, high: explicitThreshold, threshold: explicitThreshold };
  }
  const maxLevelSamples = 100_000;
  const stride = Math.max(1, Math.floor(samples.length / maxLevelSamples));
  const levelSamples = [];
  for (let index = 0; index < samples.length; index += stride) levelSamples.push(samples[index]);
  const low = percentile(levelSamples, 0.1);
  const high = percentile(levelSamples, 0.9);
  return { low, high, threshold: (low + high) / 2 };
}

export function digitalEdges(waveform, options = {}) {
  const { samples, sampleInterval, startTime = 0 } = waveform;
  const levels = thresholdLevels(samples, options.threshold);
  const hysteresis = options.hysteresis ?? Math.max((levels.high - levels.low) * 0.1, 1e-12);
  const risingThreshold = levels.threshold + hysteresis / 2;
  const fallingThreshold = levels.threshold - hysteresis / 2;
  let state = samples[0] >= levels.threshold ? 1 : 0;
  const edges = [];
  for (let index = 1; index < samples.length; index++) {
    if (!state && samples[index] >= risingThreshold) {
      state = 1;
      edges.push({ index, time: startTime + index * sampleInterval, state, type: "rising" });
    } else if (state && samples[index] <= fallingThreshold) {
      state = 0;
      edges.push({ index, time: startTime + index * sampleInterval, state, type: "falling" });
    }
  }
  return { initialState: samples[0] >= levels.threshold ? 1 : 0, edges, ...levels, hysteresis };
}

export function stateAt(edgesResult, index) {
  let low = 0;
  let high = edgesResult.edges.length;
  while (low < high) {
    const middle = Math.floor((low + high) / 2);
    if (edgesResult.edges[middle].index <= index) low = middle + 1;
    else high = middle;
  }
  return low === 0 ? edgesResult.initialState : edgesResult.edges[low - 1].state;
}

function edgeIntervals(edges, type) {
  const selected = edges.filter((edge) => edge.type === type);
  return selected.slice(1).map((edge, index) => edge.time - selected[index].time);
}

function transitionTime(samples, start, end, sampleInterval, rising, low, high) {
  const v10 = low + 0.1 * (high - low);
  const v90 = low + 0.9 * (high - low);
  let first = null;
  for (let index = start; index <= end; index++) {
    const crossed10 = rising ? samples[index] >= v10 : samples[index] <= v90;
    const crossed90 = rising ? samples[index] >= v90 : samples[index] <= v10;
    if (first == null && crossed10) first = index;
    if (first != null && crossed90) return (index - first) * sampleInterval;
  }
  return null;
}

export function measureWaveform(waveform, options = {}) {
  const values = waveform.samples;
  if (values.length < 2) throw new Error("Waveform requires at least two samples");
  const average = mean(values);
  let minimum = Infinity;
  let maximum = -Infinity;
  let squareSum = 0;
  for (const value of values) {
    if (value < minimum) minimum = value;
    if (value > maximum) maximum = value;
    squareSum += value ** 2;
  }
  const edgesResult = digitalEdges(waveform, options);
  const risingIntervals = edgeIntervals(edgesResult.edges, "rising");
  const periods = risingIntervals.filter((value) => value > 0);
  const period = median(periods);
  const highWidths = [];
  let minimumPulseWidth = null;
  for (let index = 1; index < edgesResult.edges.length; index++) {
    const width = edgesResult.edges[index].time - edgesResult.edges[index - 1].time;
    if (edgesResult.edges[index - 1].state === 1) highWidths.push(width);
    if (minimumPulseWidth == null || width < minimumPulseWidth) minimumPulseWidth = width;
  }
  const transitionTimes = [];
  for (let index = 0; index < Math.min(edgesResult.edges.length, 200); index++) {
    const edge = edgesResult.edges[index];
    const nextIndex = edgesResult.edges[index + 1]?.index ?? values.length - 1;
    const duration = transitionTime(
      values,
      Math.max(0, edge.index - 5),
      Math.min(nextIndex, edge.index + Math.ceil((period || waveform.sampleInterval * 20) / waveform.sampleInterval / 2)),
      waveform.sampleInterval,
      edge.type === "rising",
      edgesResult.low,
      edgesResult.high
    );
    if (duration != null) transitionTimes.push(duration);
  }
  return {
    sampleCount: values.length,
    sampleRate: 1 / waveform.sampleInterval,
    duration: values.length * waveform.sampleInterval,
    minimum,
    maximum,
    peakToPeak: maximum - minimum,
    mean: average,
    rms: Math.sqrt(squareSum / values.length),
    standardDeviation: standardDeviation(values, average),
    lowLevel: edgesResult.low,
    highLevel: edgesResult.high,
    threshold: edgesResult.threshold,
    edgeCount: edgesResult.edges.length,
    frequency: Number.isFinite(period) && period > 0 ? 1 / period : null,
    period: Number.isFinite(period) ? period : null,
    dutyCycle: highWidths.length && Number.isFinite(period)
      ? median(highWidths) / period
      : null,
    jitterRms: periods.length ? standardDeviation(periods) : null,
    minimumPulseWidth,
    transitionTimeMedian: transitionTimes.length ? median(transitionTimes) : null
  };
}

export function serializeWaveform(waveform, maxPreviewPoints = 100) {
  const stride = Math.max(1, Math.ceil(waveform.samples.length / maxPreviewPoints));
  const preview = [];
  for (let index = 0; index < waveform.samples.length; index += stride) {
    preview.push({
      time: waveform.startTime + index * waveform.sampleInterval,
      value: waveform.samples[index]
    });
  }
  return {
    channel: waveform.channel,
    sampleInterval: waveform.sampleInterval,
    startTime: waveform.startTime,
    sampleCount: waveform.samples.length,
    metadata: waveform.metadata,
    preview
  };
}
