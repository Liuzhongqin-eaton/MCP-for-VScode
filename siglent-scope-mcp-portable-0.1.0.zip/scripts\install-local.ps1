[CmdletBinding()]
param(
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$serverFile = Join-Path $projectRoot "src\server.js"
$skillSource = Join-Path $projectRoot ".github\skills\siglent-scope"

function Get-NodeCommand {
    $command = Get-Command node -ErrorAction SilentlyContinue
    if ($command) {
        return $command.Source
    }

    $wingetRoot = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages"
    $candidate = Get-ChildItem $wingetRoot -Filter node.exe -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match "OpenJS\.NodeJS" } |
        Sort-Object FullName -Descending |
        Select-Object -First 1
    if ($candidate) {
        return $candidate.FullName
    }

    throw "Node.js 20 or newer is required. Install Node.js LTS, then run this script again."
}

function Assert-NodeVersion($nodeCommand) {
    $versionText = & $nodeCommand --version
    if (-not $versionText -or [int]($versionText.TrimStart("v").Split(".")[0]) -lt 20) {
        throw "Node.js 20 or newer is required. Found: $versionText"
    }
}

function Ensure-ObjectProperty($object, $name) {
    if (-not $object.PSObject.Properties[$name]) {
        $object | Add-Member -MemberType NoteProperty -Name $name -Value ([pscustomobject]@{})
    }
    return $object.$name
}

function Read-JsonObject($file) {
    if (Test-Path $file) {
        $raw = Get-Content $file -Raw
        if ($raw.Trim()) {
            return $raw | ConvertFrom-Json
        }
    }
    return [pscustomobject]@{}
}

function Write-JsonObject($file, $value) {
    $directory = Split-Path -Parent $file
    New-Item -ItemType Directory -Force -Path $directory | Out-Null
    if (Test-Path $file) {
        Copy-Item $file "$file.siglent-backup" -Force
    }
    $value | ConvertTo-Json -Depth 20 | Set-Content -Path $file -Encoding UTF8
}

$nodeCommand = Get-NodeCommand
Assert-NodeVersion $nodeCommand

$npmCommand = Join-Path (Split-Path -Parent $nodeCommand) "npm.cmd"
if (-not (Test-Path $npmCommand)) {
    throw "npm.cmd was not found next to Node.js: $nodeCommand"
}

Push-Location $projectRoot
try {
    & $npmCommand ci
    if ($LASTEXITCODE -ne 0) {
        throw "npm ci failed with exit code $LASTEXITCODE"
    }
    if (-not $SkipTests) {
        & $npmCommand test
        if ($LASTEXITCODE -ne 0) {
            throw "Automated tests failed with exit code $LASTEXITCODE"
        }
    }
} finally {
    Pop-Location
}

$vscodeConfig = Join-Path $env:APPDATA "Code\User\mcp.json"
$vscodeJson = Read-JsonObject $vscodeConfig
$vscodeServers = Ensure-ObjectProperty $vscodeJson "servers"
$vscodeEntry = [pscustomobject]@{
    type = "stdio"
    command = $nodeCommand
    args = @($serverFile)
}
if ($vscodeServers.PSObject.Properties["siglent-scope"]) {
    $vscodeServers."siglent-scope" = $vscodeEntry
} else {
    $vscodeServers | Add-Member -MemberType NoteProperty -Name "siglent-scope" -Value $vscodeEntry
}
Write-JsonObject $vscodeConfig $vscodeJson

$copilotConfig = Join-Path $HOME ".copilot\mcp-config.json"
$copilotJson = Read-JsonObject $copilotConfig
$copilotServers = Ensure-ObjectProperty $copilotJson "mcpServers"
$copilotEntry = [pscustomobject]@{
    type = "stdio"
    command = $nodeCommand
    args = @($serverFile)
    env = [pscustomobject]@{}
    tools = @("*")
}
if ($copilotServers.PSObject.Properties["siglent-scope"]) {
    $copilotServers."siglent-scope" = $copilotEntry
} else {
    $copilotServers | Add-Member -MemberType NoteProperty -Name "siglent-scope" -Value $copilotEntry
}
Write-JsonObject $copilotConfig $copilotJson

$skillTarget = Join-Path $HOME ".copilot\skills\siglent-scope"
New-Item -ItemType Directory -Force -Path $skillTarget | Out-Null
Copy-Item (Join-Path $skillSource "SKILL.md") (Join-Path $skillTarget "SKILL.md") -Force

Write-Host ""
Write-Host "Siglent Scope MCP installed successfully." -ForegroundColor Green
Write-Host "Project: $projectRoot"
Write-Host "Restart VS Code, trust the siglent-scope MCP server, then connect to the scope LAN."
