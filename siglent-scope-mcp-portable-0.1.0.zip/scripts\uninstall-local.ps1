[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

function Remove-ServerEntry($file, $containerName) {
    if (-not (Test-Path $file)) {
        return
    }
    $json = Get-Content $file -Raw | ConvertFrom-Json
    $container = $json.$containerName
    if ($container -and $container.PSObject.Properties["siglent-scope"]) {
        $container.PSObject.Properties.Remove("siglent-scope")
        Copy-Item $file "$file.siglent-backup" -Force
        $json | ConvertTo-Json -Depth 20 | Set-Content -Path $file -Encoding UTF8
    }
}

Remove-ServerEntry (Join-Path $env:APPDATA "Code\User\mcp.json") "servers"
Remove-ServerEntry (Join-Path $HOME ".copilot\mcp-config.json") "mcpServers"

$skillFile = Join-Path $HOME ".copilot\skills\siglent-scope\SKILL.md"
if (Test-Path $skillFile) {
    Remove-Item $skillFile -Force
}

Write-Host "Siglent Scope MCP user configuration was removed." -ForegroundColor Green
