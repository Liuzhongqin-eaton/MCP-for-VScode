export function analyzeSignalQuality(metrics, context = {}) {
  const findings = [];
  const expectedRate = context.frequency ?? context.baudRate;
  if (expectedRate && metrics.sampleRate / expectedRate < 10) {
    findings.push({
      code: "insufficient-sample-rate",
      severity: "high",
      confidence: 0.99,
      evidence: {
        sampleRate: metrics.sampleRate,
        expectedRate,
        samplesPerSymbol: metrics.sampleRate / expectedRate
      },
      explanation: "The acquisition has fewer than 10 samples per bit/clock.",
      alternatives: ["Increase sample rate", "Reduce time span or active channels"]
    });
  }
  if (expectedRate && metrics.frequency) {
    const error = Math.abs(metrics.frequency - expectedRate) / expectedRate;
    if (error > (context.frequencyTolerance ?? 0.03)) {
      findings.push({
        code: "frequency-deviation",
        severity: error > 0.1 ? "high" : "medium",
        confidence: Math.min(0.99, 0.7 + error),
        evidence: { measured: metrics.frequency, expected: expectedRate, relativeError: error },
        explanation: "Measured timing differs from the configured protocol rate.",
        alternatives: ["Incorrect protocol rate", "Clock drift", "Threshold or probe distortion"]
      });
    }
  }
  if (metrics.period && metrics.minimumPulseWidth && metrics.minimumPulseWidth < metrics.period * 0.2) {
    findings.push({
      code: "narrow-pulse",
      severity: "high",
      confidence: 0.9,
      evidence: { minimumPulseWidth: metrics.minimumPulseWidth, nominalPeriod: metrics.period },
      explanation: "A pulse shorter than 20% of the nominal period was detected.",
      alternatives: ["Electrical glitch", "Ringing crossing the threshold", "Legitimate variable-width signaling"]
    });
  }
  if (metrics.period && metrics.jitterRms != null && metrics.jitterRms / metrics.period > 0.03) {
    findings.push({
      code: "excessive-jitter",
      severity: "medium",
      confidence: 0.82,
      evidence: { jitterRms: metrics.jitterRms, period: metrics.period },
      explanation: "Cycle-to-cycle RMS jitter exceeds 3% of the period.",
      alternatives: ["Clock-source instability", "Threshold noise", "Insufficient sample rate"]
    });
  }
  const swing = metrics.highLevel - metrics.lowLevel;
  const overshoot = swing > 0 ? (metrics.maximum - metrics.highLevel) / swing : 0;
  const undershoot = swing > 0 ? (metrics.lowLevel - metrics.minimum) / swing : 0;
  if (overshoot > 0.15 || undershoot > 0.15) {
    findings.push({
      code: "overshoot-undershoot",
      severity: Math.max(overshoot, undershoot) > 0.3 ? "high" : "medium",
      confidence: 0.78,
      evidence: { overshoot, undershoot, lowLevel: metrics.lowLevel, highLevel: metrics.highLevel },
      explanation: "The waveform exceeds its steady-state levels by more than 15%.",
      alternatives: ["Impedance mismatch", "Long probe ground", "Incorrect termination"]
    });
  }
  return findings;
}

export function compareToBaseline(current, baseline, tolerances = {}) {
  const defaults = {
    frequency: 0.03,
    peakToPeak: 0.1,
    dutyCycle: 0.08,
    jitterRms: 0.5,
    transitionTimeMedian: 0.5
  };
  const differences = [];
  for (const [metric, tolerance] of Object.entries({ ...defaults, ...tolerances })) {
    const actual = current[metric];
    const expected = baseline[metric];
    if (!Number.isFinite(actual) || !Number.isFinite(expected)) continue;
    const denominator = Math.max(Math.abs(expected), Number.EPSILON);
    const relativeDifference = Math.abs(actual - expected) / denominator;
    if (relativeDifference > tolerance) {
      differences.push({ metric, actual, expected, relativeDifference, tolerance });
    }
  }
  return {
    passed: differences.length === 0,
    score: Math.max(0, 1 - differences.reduce((sum, item) => sum + item.relativeDifference, 0) /
      Math.max(1, differences.length)),
    differences
  };
}

export function compareWaveformShape(current, baseline, pointCount = 1024) {
  const count = Math.min(pointCount, current.samples.length, baseline.samples.length);
  if (count < 8) throw new Error("At least eight samples are required for waveform comparison");
  const currentValues = [];
  const baselineValues = [];
  for (let index = 0; index < count; index++) {
    currentValues.push(current.samples[Math.floor(index * (current.samples.length - 1) / (count - 1))]);
    baselineValues.push(baseline.samples[Math.floor(index * (baseline.samples.length - 1) / (count - 1))]);
  }
  const normalize = (values) => {
    const average = values.reduce((sum, value) => sum + value, 0) / values.length;
    const deviation = Math.sqrt(
      values.reduce((sum, value) => sum + (value - average) ** 2, 0) / values.length
    ) || 1;
    return values.map((value) => (value - average) / deviation);
  };
  const left = normalize(currentValues);
  const right = normalize(baselineValues);
  const correlation = left.reduce((sum, value, index) => sum + value * right[index], 0) / count;
  const normalizedRmse = Math.sqrt(
    left.reduce((sum, value, index) => sum + (value - right[index]) ** 2, 0) / count
  );
  return { correlation, normalizedRmse, comparedPoints: count };
}
