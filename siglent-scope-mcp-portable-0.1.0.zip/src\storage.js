import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { DATA_DIR } from "./config.js";
import { timestampId } from "./util.js";

async function ensureDirectory(directory) {
  await fs.mkdir(directory, { recursive: true });
  return directory;
}

async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return fallback;
    throw new Error(`Cannot read ${file}: ${error.message}`, { cause: error });
  }
}

async function atomicWriteJson(file, value) {
  await ensureDirectory(path.dirname(file));
  const temporary = `${file}.${process.pid}.${randomUUID()}.tmp`;
  await fs.writeFile(temporary, JSON.stringify(value, null, 2), "utf8");
  await fs.rename(temporary, file);
}

const fileLocks = new Map();

async function withFileLock(file, operation) {
  const previous = fileLocks.get(file) ?? Promise.resolve();
  const current = previous.catch(() => {}).then(operation);
  fileLocks.set(file, current);
  try {
    return await current;
  } finally {
    if (fileLocks.get(file) === current) fileLocks.delete(file);
  }
}

export class Store {
  constructor(root = DATA_DIR) {
    this.root = root;
  }

  file(name) {
    return path.join(this.root, name);
  }

  async listDevices() {
    return readJson(this.file("devices.json"), []);
  }

  async upsertDevice(device) {
    const file = this.file("devices.json");
    return withFileLock(file, async () => {
      const devices = await readJson(file, []);
      const index = devices.findIndex((item) => item.host === device.host && item.port === device.port);
      const record = { ...devices[index], ...device, updatedAt: new Date().toISOString() };
      if (index >= 0) devices[index] = record;
      else devices.push(record);
      await atomicWriteJson(file, devices);
      return record;
    });
  }

  async audit(event) {
    await ensureDirectory(this.root);
    await fs.appendFile(this.file("audit.jsonl"), `${JSON.stringify({
      timestamp: new Date().toISOString(),
      ...event
    })}\n`, "utf8");
  }

  async saveCapture(capture) {
    const id = capture.id ?? timestampId("capture");
    const directory = await ensureDirectory(path.join(this.root, "captures", id));
    const manifest = { ...capture, id, waveforms: {} };
    for (const [name, waveform] of Object.entries(capture.waveforms ?? {})) {
      const sampleFile = `${name}.f64`;
      const bytes = Buffer.from(
        waveform.samples.buffer,
        waveform.samples.byteOffset,
        waveform.samples.byteLength
      );
      await fs.writeFile(path.join(directory, sampleFile), bytes);
      manifest.waveforms[name] = { ...waveform, samples: undefined, sampleFile };
    }
    await atomicWriteJson(path.join(directory, "manifest.json"), manifest);
    return { id, directory, manifest };
  }

  async loadCapture(id) {
    const directory = path.join(this.root, "captures", path.basename(id));
    const manifest = await readJson(path.join(directory, "manifest.json"), null);
    if (!manifest) throw new Error(`Capture not found: ${id}`);
    const waveforms = {};
    for (const [name, waveform] of Object.entries(manifest.waveforms ?? {})) {
      const bytes = await fs.readFile(path.join(directory, waveform.sampleFile));
      const sampleBuffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
      waveforms[name] = {
        ...waveform,
        samples: new Float64Array(sampleBuffer)
      };
    }
    return { ...manifest, waveforms };
  }

  async saveBaseline(name, data) {
    const safeName = name.replaceAll(/[^a-zA-Z0-9_-]/g, "_");
    await atomicWriteJson(this.file(path.join("baselines", `${safeName}.json`)), data);
    return safeName;
  }

  async loadBaseline(name) {
    const safeName = name.replaceAll(/[^a-zA-Z0-9_-]/g, "_");
    const result = await readJson(this.file(path.join("baselines", `${safeName}.json`)), null);
    if (!result) throw new Error(`Baseline not found: ${name}`);
    return result;
  }

  async addLabel(label) {
    const file = this.file("labels.json");
    return withFileLock(file, async () => {
      const labels = await readJson(file, []);
      labels.push({ id: timestampId("label"), createdAt: new Date().toISOString(), ...label });
      await atomicWriteJson(file, labels);
      return labels.at(-1);
    });
  }

  async getLabels(project) {
    const labels = await readJson(this.file("labels.json"), []);
    return project ? labels.filter((item) => item.project === project) : labels;
  }

  async saveRules(project, rules) {
    const safeProject = project.replaceAll(/[^a-zA-Z0-9_-]/g, "_");
    await atomicWriteJson(this.file(path.join("rules", `${safeProject}.json`)), rules);
    return rules;
  }

  async loadRules(project) {
    const safeProject = project.replaceAll(/[^a-zA-Z0-9_-]/g, "_");
    return readJson(this.file(path.join("rules", `${safeProject}.json`)), []);
  }
}
