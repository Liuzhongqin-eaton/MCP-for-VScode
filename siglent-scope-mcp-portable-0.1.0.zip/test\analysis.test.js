import test from "node:test";
import assert from "node:assert/strict";
import { planAcquisition } from "../src/acquisition.js";
import { measureWaveform } from "../src/analysis/waveform.js";
import { compareToBaseline } from "../src/analysis/quality.js";
import { decodeI2c, decodeSpi, decodeUart } from "../src/analysis/protocols.js";

function waveformFromStates(states, sampleInterval = 1e-6) {
  return {
    samples: Float64Array.from(states),
    sampleInterval,
    startTime: 0,
    metadata: {}
  };
}

test("automatic acquisition planning reserves timing-analysis resolution", () => {
  const plan = planAcquisition({
    signalRate: 10e6,
    protocol: "spi",
    frameBits: 8,
    frames: 20,
    family: "sds1000x-e",
    activeChannels: 4
  });
  assert.equal(plan.targetSampleRate, 400e6);
  assert.ok(plan.targetPoints >= 6_400);
  assert.equal(plan.memoryDepth, "7K");
});

test("waveform measurements recover frequency and duty cycle", () => {
  const samples = new Float64Array(10_000);
  const samplesPerPeriod = 100;
  for (let index = 0; index < samples.length; index++) {
    samples[index] = index % samplesPerPeriod < 40 ? 3.3 : 0;
  }
  const metrics = measureWaveform({ samples, sampleInterval: 1e-8, startTime: 0 });
  assert.ok(Math.abs(metrics.frequency - 1e6) < 1);
  assert.ok(Math.abs(metrics.dutyCycle - 0.4) < 0.02);
  assert.ok(metrics.peakToPeak > 3.2);
});

test("SPI decoder reads an eight-bit mode-0 transaction", () => {
  const length = 220;
  const clock = Array(length).fill(0);
  const chipSelect = Array(length).fill(1);
  const mosi = Array(length).fill(0);
  const bits = [1, 0, 1, 0, 0, 1, 0, 1];
  for (let bit = 0; bit < bits.length; bit++) {
    const start = 20 + bit * 20;
    for (let index = start; index < start + 20; index++) {
      chipSelect[index] = 0;
      mosi[index] = bits[bit];
      clock[index] = index >= start + 10 ? 1 : 0;
    }
  }
  const decoded = decodeSpi({
    clock: waveformFromStates(clock),
    chipSelect: waveformFromStates(chipSelect),
    mosi: waveformFromStates(mosi)
  }, { cpol: 0, cpha: 0, wordBits: 8, bitOrder: "msb" });
  assert.equal(decoded.frames.length, 1);
  assert.equal(decoded.frames[0].mosi, 0xa5);
  assert.equal(decoded.findings.length, 0);
});

test("I2C decoder identifies address, direction, data, and ACK", () => {
  const scl = [1, 1, 1, 1];
  const sda = [1, 1, 0, 0];
  const appendBit = (bit) => {
    scl.push(0, 0, 1, 1);
    sda.push(bit, bit, bit, bit);
  };
  for (const bit of [1, 0, 1, 0, 0, 0, 0, 0, 0]) appendBit(bit);
  for (const bit of [0, 1, 0, 1, 1, 0, 1, 0, 0]) appendBit(bit);
  scl.push(1, 1);
  sda.push(0, 1);
  const decoded = decodeI2c({
    scl: waveformFromStates(scl),
    sda: waveformFromStates(sda)
  });
  assert.equal(decoded.transactions.length, 1);
  assert.equal(decoded.transactions[0].address, 0x50);
  assert.equal(decoded.transactions[0].direction, "write");
  assert.equal(decoded.transactions[0].bytes[1].value, 0x5a);
  assert.equal(decoded.findings.length, 0);
});

test("UART decoder recovers 8N1 data", () => {
  const samplesPerBit = 20;
  const states = Array(samplesPerBit * 3).fill(1);
  const byte = 0x53;
  states.push(...Array(samplesPerBit).fill(0));
  for (let bit = 0; bit < 8; bit++) {
    states.push(...Array(samplesPerBit).fill((byte >> bit) & 1));
  }
  states.push(...Array(samplesPerBit * 2).fill(1));
  const decoded = decodeUart(waveformFromStates(states, 1 / (9600 * samplesPerBit)), {
    baudRate: 9600,
    dataBits: 8,
    parity: "none",
    stopBits: 1
  });
  assert.equal(decoded.frames.length, 1);
  assert.equal(decoded.frames[0].value, byte);
  assert.equal(decoded.frames[0].framingOk, true);
});

test("baseline comparison reports metric deviations", () => {
  const result = compareToBaseline(
    { frequency: 900, peakToPeak: 3.3 },
    { frequency: 1000, peakToPeak: 3.3 }
  );
  assert.equal(result.passed, false);
  assert.equal(result.differences[0].metric, "frequency");
});

test("SPI decoder never combines partial words across chip-select windows", () => {
  const clock = Array(220).fill(0);
  const chipSelect = Array(220).fill(1);
  const mosi = Array(220).fill(0);
  for (const windowStart of [20, 120]) {
    for (let bit = 0; bit < 4; bit++) {
      const start = windowStart + bit * 20;
      for (let index = start; index < start + 20; index++) {
        chipSelect[index] = 0;
        mosi[index] = bit % 2;
        clock[index] = index >= start + 10 ? 1 : 0;
      }
    }
  }
  const decoded = decodeSpi({
    clock: waveformFromStates(clock),
    chipSelect: waveformFromStates(chipSelect),
    mosi: waveformFromStates(mosi)
  }, { cpol: 0, cpha: 0, wordBits: 8 });
  assert.equal(decoded.frames.length, 0);
  assert.equal(decoded.findings.length, 2);
});

test("deep transition records do not exceed the JavaScript argument limit", () => {
  const samples = Float64Array.from({ length: 300_000 }, (_, index) => index % 2);
  const metrics = measureWaveform({ samples, sampleInterval: 1e-9, startTime: 0 });
  assert.ok(Math.abs(metrics.minimumPulseWidth - 1e-9) < 1e-18);
});
