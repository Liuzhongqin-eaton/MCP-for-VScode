import test from "node:test";
import assert from "node:assert/strict";
import net from "node:net";
import { ScpiTransport } from "../src/scpi/transport.js";
import { Sds1000XhdAdapter } from "../src/scpi/adapters.js";
import { getConfig } from "../src/config.js";

test("IEEE block terminator is consumed before the next line query", async (context) => {
  const server = net.createServer((socket) => {
    let input = "";
    socket.on("data", (chunk) => {
      input += chunk.toString("ascii");
      let newline;
      while ((newline = input.indexOf("\n")) >= 0) {
        const command = input.slice(0, newline).trim();
        input = input.slice(newline + 1);
        if (command === "BLOCK?") socket.write(Buffer.from("#13abc\n"));
        if (command === "NEXT?") socket.write("42\n");
      }
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const transport = new ScpiTransport("127.0.0.1", getConfig({
    allowedHosts: ["127.0.0.1"],
    commandTimeoutMs: 1000
  }), { port: server.address().port });
  context.after(async () => {
    transport.close();
    await new Promise((resolve) => server.close(resolve));
  });
  assert.equal((await transport.queryBinary("BLOCK?")).toString(), "abc");
  assert.equal(await transport.queryLine("NEXT?"), "42");
});

test("HD adapter retrieves every waveform chunk and computes pre-trigger time", async () => {
  const descriptor = Buffer.alloc(0x14c);
  descriptor.writeUInt32LE(5, 0x74);
  descriptor.writeUInt32LE(1, 0x90);
  descriptor.writeFloatLE(1, 0x9c);
  descriptor.writeFloatLE(0, 0xa0);
  descriptor.writeFloatLE(25, 0xa4);
  descriptor.writeInt16LE(12, 0xac);
  descriptor.writeFloatLE(1e-6, 0xb0);
  descriptor.writeDoubleLE(0, 0xb4);
  descriptor.writeInt16LE(20, 0x144);
  descriptor.writeFloatLE(1, 0x148);
  let start = 0;
  let count = 0;
  const commands = [];
  const transport = {
    port: 5025,
    config: getConfig({ maxWaveformPoints: 100 }),
    async write(command) {
      commands.push(command);
      if (command.startsWith(":WAVeform:STARt ")) start = Number(command.split(" ").at(-1));
      if (command.startsWith(":WAVeform:POINt ")) count = Number(command.split(" ").at(-1));
    },
    async queryLine(command) {
      if (command === ":WAVeform:MAXPoint?") return "2";
      throw new Error(`Unexpected query: ${command}`);
    },
    async queryBinary(command) {
      if (command === ":WAVeform:PREamble?") return descriptor;
      if (command === ":WAVeform:DATA?") {
        const data = Buffer.alloc(count * 2);
        for (let index = 0; index < count; index++) data.writeInt16LE(start + index, index * 2);
        return data;
      }
      throw new Error(`Unexpected binary query: ${command}`);
    }
  };
  const adapter = new Sds1000XhdAdapter(transport, { model: "SDS1204X HD" });
  const waveform = await adapter.readWaveform(1);
  assert.deepEqual(Array.from(waveform.samples), [0, 0.04, 0.08, 0.12, 0.16]);
  assert.ok(Math.abs(waveform.startTime + 0.005) < 1e-12);
  assert.ok(commands.includes(":WAVeform:STARt 4"));
});
