---
name: siglent-scope
description: 'Operate and analyze Siglent/鼎阳 SDS1204X oscilloscope waveforms. Use when: discovering a scope by IP, configuring acquisition, capturing waveforms, diagnosing signal integrity, decoding SPI/I2C/IIC/UART, monitoring intermittent faults, comparing a baseline, correlating serial/CAN/firmware logs, or generating a waveform report.'
argument-hint: 'Describe the signal, channel mapping, frequency/baud rate, expected behavior, and fault symptom'
---

# Siglent Scope Automation

Use the `siglent_*` MCP tools. Never infer waveform facts without acquired samples or a saved capture.

## Workflow

1. Call `siglent_list_devices`; if the device is absent, call `siglent_discover` or `siglent_register`.
2. Call `siglent_inspect` before changing settings. Confirm the exact model family and current setup.
3. Translate the user's description into:
   - protocol and frequency/baud rate;
   - channel-to-signal mapping;
   - electrical threshold or expected voltage;
   - expected data/timing and observed symptom.
4. Prefer a read-only capture when existing settings are suitable.
5. For automatic setup, explain the planned write and restore behavior. Set `configure: true` and `allowWrite: true` only for a device registered with write access.
6. Call `siglent_capture_analyze`. Use raw samples, not screenshots, for decoding or timing claims.
7. Report observed evidence and timestamp, likely cause and confidence, plausible alternatives, and the next discriminating measurement.
8. For intermittent faults, call `siglent_monitor` with `stopOnAnomaly: true`.
9. Save a known-good capture with `siglent_save_baseline`. Label at least three normal captures before calling `siglent_learn_rules`.
10. Use `siglent_correlate_logs` for serial, CAN, or firmware logs with timestamps.

## Protocol mappings

- SPI: `clock`, `chipSelect`, and one or both of `mosi`, `miso`.
- I2C/IIC: `scl`, `sda`.
- UART: `uart` or `rx`.

Provide CPOL, CPHA, word length, bit order, and CS polarity for SPI. Provide baud rate, data bits, parity, stop bits, and polarity for UART.

## Safety

- Do not use raw write commands.
- Do not connect to public IP addresses unless explicitly allowlisted.
- Keep `restore: true` unless the user explicitly wants settings retained.
- Treat model-dependent unsupported commands as capability limits, not evidence of signal failure.
