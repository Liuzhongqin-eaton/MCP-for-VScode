import { mean, standardDeviation } from "./util.js";

const LEARNABLE_METRICS = [
  "frequency",
  "peakToPeak",
  "dutyCycle",
  "jitterRms",
  "transitionTimeMedian",
  "minimumPulseWidth"
];

export function learnRules(labels) {
  const normal = labels.filter((item) => item.label === "normal" && item.metrics);
  if (new Set(normal.map((item) => item.captureId)).size < 3) {
    throw new Error("At least three normal labeled captures are required to learn rules");
  }
  const rules = [];
  for (const channel of new Set(normal.map((item) => item.channel))) {
    const channelLabels = normal.filter((item) => item.channel === channel);
    for (const metric of LEARNABLE_METRICS) {
      const values = channelLabels.map((item) => item.metrics[metric]).filter(Number.isFinite);
      if (values.length < 3) continue;
      const average = mean(values);
      const deviation = standardDeviation(values, average);
      const margin = Math.max(3 * deviation, Math.abs(average) * 0.01, Number.EPSILON);
      rules.push({
        channel,
        metric,
        minimum: average - margin,
        maximum: average + margin,
        learnedFrom: values.length,
        method: "mean-plus-minus-3-sigma-with-1-percent-floor"
      });
    }
  }
  return rules;
}

export function evaluateRules(metrics, rules, channel) {
  const findings = [];
  for (const rule of rules.filter((item) => item.channel === channel)) {
    const value = metrics[rule.metric];
    if (!Number.isFinite(value)) continue;
    if (value < rule.minimum || value > rule.maximum) {
      const distance = value < rule.minimum ? rule.minimum - value : value - rule.maximum;
      const span = Math.max(rule.maximum - rule.minimum, Number.EPSILON);
      findings.push({
        code: `learned-rule-${rule.metric}`,
        severity: distance / span > 1 ? "high" : "medium",
        confidence: Math.min(0.98, 0.75 + 0.1 * Math.log10(rule.learnedFrom + 1)),
        evidence: { value, minimum: rule.minimum, maximum: rule.maximum, learnedFrom: rule.learnedFrom },
        explanation: `${rule.metric} falls outside the range learned from normal captures.`,
        alternatives: ["Operating conditions differ from the learned baseline"]
      });
    }
  }
  return findings;
}
