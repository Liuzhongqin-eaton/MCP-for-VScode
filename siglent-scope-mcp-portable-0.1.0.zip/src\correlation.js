import fs from "node:fs/promises";
import path from "node:path";

function parseCsvLine(line) {
  const values = [];
  let value = "";
  let quoted = false;
  for (let index = 0; index < line.length; index++) {
    const character = line[index];
    if (character === '"') {
      if (quoted && line[index + 1] === '"') {
        value += '"';
        index++;
      } else quoted = !quoted;
    } else if (character === "," && !quoted) {
      values.push(value);
      value = "";
    } else value += character;
  }
  values.push(value);
  return values;
}

function normalizeEvent(event, source, index) {
  const rawTimestamp = event.timestamp ?? event.time ?? event.ts;
  const timestamp = typeof rawTimestamp === "number"
    ? rawTimestamp
    : Date.parse(rawTimestamp);
  if (!Number.isFinite(timestamp)) {
    throw new Error(`Event ${index + 1} in ${source} has no valid timestamp`);
  }
  return { ...event, timestamp, source };
}

export async function loadEvents(file) {
  const extension = path.extname(file).toLowerCase();
  const text = await fs.readFile(file, "utf8");
  let records;
  if (extension === ".json") {
    const parsed = JSON.parse(text);
    records = Array.isArray(parsed) ? parsed : parsed.events;
  } else if (extension === ".jsonl" || extension === ".log") {
    records = text.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line));
  } else if (extension === ".csv") {
    const lines = text.split(/\r?\n/).filter(Boolean);
    const headers = parseCsvLine(lines.shift());
    records = lines.map((line) => Object.fromEntries(
      headers.map((header, index) => [header, parseCsvLine(line)[index]])
    ));
  } else {
    throw new Error(`Unsupported event log format: ${extension}`);
  }
  if (!Array.isArray(records)) throw new Error(`Event log ${file} must contain an array`);
  return records.map((event, index) => normalizeEvent(event, file, index));
}

export async function correlateEvents({ captureTimestamp, eventFiles, windowMs = 1000 }) {
  const center = typeof captureTimestamp === "number"
    ? captureTimestamp
    : Date.parse(captureTimestamp);
  if (!Number.isFinite(center)) throw new Error("captureTimestamp is invalid");
  const eventSets = await Promise.all(eventFiles.map(loadEvents));
  return eventSets.flat()
    .map((event) => ({ ...event, deltaMs: event.timestamp - center }))
    .filter((event) => Math.abs(event.deltaMs) <= windowMs)
    .sort((a, b) => Math.abs(a.deltaMs) - Math.abs(b.deltaMs));
}
